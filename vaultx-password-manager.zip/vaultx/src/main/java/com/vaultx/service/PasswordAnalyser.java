package com.vaultx.service;

import com.vaultx.crypto.CryptoUtil;
import com.vaultx.dsa.BloomFilter;
import com.vaultx.model.PasswordStrengthResult;

import java.util.*;
import java.util.regex.Pattern;

/**
 * ============================================================
 * PASSWORD ANALYSER
 * ============================================================
 * Scores a password across 5 dimensions (20 pts each = 100 max):
 *
 *   1. LENGTH         — raw character count
 *   2. COMPLEXITY     — charset diversity (upper/lower/digit/symbol)
 *   3. PATTERN        — penalises repetitions, sequences, keyboard walks
 *   4. DICTIONARY     — penalises common words / top-10K passwords
 *   5. ENTROPY        — information-theoretic bits of entropy
 *
 * Also checks the Bloom filter for breached passwords (HIBP-style).
 *
 * DSA used: BloomFilter (O(k) breach lookup), HashSet (dictionary)
 * ============================================================
 */
public class PasswordAnalyser {

    private static final BloomFilter    breachFilter   = new BloomFilter();
    private static final Set<String>    commonPasswords = new HashSet<>();
    private static       boolean        initialised     = false;

    // ----------------------------------------------------------
    // Singleton init — loads common passwords + breach hashes
    // ----------------------------------------------------------
    public static synchronized void init() {
        if (initialised) return;
        loadCommonPasswords();
        seedBreachFilter();
        initialised = true;
    }

    // ------------------------------------------------------------------ //
    //  Main Analysis
    // ------------------------------------------------------------------ //

    public static PasswordStrengthResult analyse(String password) {
        init();
        PasswordStrengthResult result = new PasswordStrengthResult();

        if (password == null || password.isEmpty()) {
            result.setScore(0);
            result.computeGrade();
            result.addWarning("Password cannot be empty.");
            return result;
        }

        // ---- Sub-scores ----
        int lengthScore     = scorLength(password, result);
        int complexityScore = scoreComplexity(password, result);
        int patternScore    = scorePattern(password, result);
        int dictionaryScore = scoreDictionary(password, result);
        int entropyScore    = scoreEntropy(password, result);

        result.setLengthScore(lengthScore);
        result.setComplexityScore(complexityScore);
        result.setPatternScore(patternScore);
        result.setDictionaryScore(dictionaryScore);
        result.setEntropyScore(entropyScore);

        int total = lengthScore + complexityScore + patternScore + dictionaryScore + entropyScore;
        result.setScore(Math.min(100, Math.max(0, total)));
        result.computeGrade();

        // ---- Breach check ----
        String sha256 = CryptoUtil.sha256(password);
        if (breachFilter.mightContain(sha256)) {
            result.setBreached(true);
            result.addWarning("⚠ This password has appeared in known data breaches. Change it immediately!");
            result.setScore(Math.min(result.getScore(), 10));  // cap breached passwords
            result.computeGrade();
        }

        return result;
    }

    // ------------------------------------------------------------------ //
    //  1. Length (max 20 pts)
    // ------------------------------------------------------------------ //

    private static int scorLength(String pw, PasswordStrengthResult r) {
        int len = pw.length();
        if (len < 6)  { r.addWarning("Password is too short (< 6 chars).");
                        r.addSuggestion("Use at least 12 characters."); return 0; }
        if (len < 8)  { r.addSuggestion("Consider 12+ characters for better security."); return 5; }
        if (len < 12) { return 10; }
        if (len < 16) { return 15; }
        return 20;  // 16+ chars → full marks
    }

    // ------------------------------------------------------------------ //
    //  2. Complexity (max 20 pts)
    // ------------------------------------------------------------------ //

    private static int scoreComplexity(String pw, PasswordStrengthResult r) {
        boolean hasLower  = pw.chars().anyMatch(Character::isLowerCase);
        boolean hasUpper  = pw.chars().anyMatch(Character::isUpperCase);
        boolean hasDigit  = pw.chars().anyMatch(Character::isDigit);
        boolean hasSymbol = pw.chars().anyMatch(c -> !Character.isLetterOrDigit(c));

        int charSets = (hasLower?1:0) + (hasUpper?1:0) + (hasDigit?1:0) + (hasSymbol?1:0);

        if (!hasLower  || !hasUpper) r.addSuggestion("Mix upper and lowercase letters.");
        if (!hasDigit)               r.addSuggestion("Add numbers.");
        if (!hasSymbol)              r.addSuggestion("Add symbols (!, @, #, $, ...).");

        return switch (charSets) {
            case 1 -> 2;
            case 2 -> 8;
            case 3 -> 14;
            case 4 -> 20;
            default -> 0;
        };
    }

    // ------------------------------------------------------------------ //
    //  3. Pattern score (max 20 pts — penalties applied)
    // ------------------------------------------------------------------ //

    private static int scorePattern(String pw, PasswordStrengthResult r) {
        int score = 20;
        String lower = pw.toLowerCase();

        // Repeated characters (aaa, 111)
        if (Pattern.compile("(.)\\1{2,}").matcher(pw).find()) {
            score -= 8;
            r.addWarning("Avoid repeating characters (e.g. 'aaa').");
        }

        // Sequential keyboard rows
        String[] rows = {"qwertyuiop", "asdfghjkl", "zxcvbnm", "1234567890"};
        for (String row : rows) {
            for (int i = 0; i <= row.length() - 4; i++) {
                if (lower.contains(row.substring(i, i + 4))) {
                    score -= 6;
                    r.addWarning("Avoid keyboard sequences (e.g. 'qwert').");
                    break;
                }
            }
        }

        // Alphabetic sequences (abcd, wxyz)
        for (int i = 0; i <= lower.length() - 4; i++) {
            boolean seq = true;
            for (int j = i; j < i + 3; j++) {
                if (lower.charAt(j+1) - lower.charAt(j) != 1) { seq = false; break; }
            }
            if (seq) { score -= 5; r.addWarning("Avoid alphabetic sequences (e.g. 'abcd')."); break; }
        }

        // Repeating blocks (abcabc)
        if (hasRepeatingBlock(pw)) {
            score -= 6;
            r.addWarning("Avoid repeating word blocks (e.g. 'abcabc').");
        }

        // Leet-speak detection (p@ssw0rd)
        String deleet = lower.replace("@","a").replace("0","o")
                .replace("1","i").replace("3","e").replace("$","s");
        if (commonPasswords.contains(deleet)) {
            score -= 10;
            r.addWarning("Leet-speak substitutions do not make common words secure.");
        }

        return Math.max(0, score);
    }

    private static boolean hasRepeatingBlock(String pw) {
        int len = pw.length();
        for (int blockLen = 2; blockLen <= len / 2; blockLen++) {
            String block = pw.substring(0, blockLen);
            String rest  = pw.substring(blockLen);
            if (rest.startsWith(block)) return true;
        }
        return false;
    }

    // ------------------------------------------------------------------ //
    //  4. Dictionary check (max 20 pts)
    // ------------------------------------------------------------------ //

    private static int scoreDictionary(String pw, PasswordStrengthResult r) {
        String lower = pw.toLowerCase().replaceAll("[^a-z]", "");

        if (commonPasswords.contains(lower)) {
            r.addWarning("This is a commonly used password. It will be cracked instantly.");
            return 0;
        }

        // Check substrings of length 5+
        for (int len = 6; len <= Math.min(lower.length(), 10); len++) {
            for (int i = 0; i <= lower.length() - len; i++) {
                if (commonPasswords.contains(lower.substring(i, i + len))) {
                    r.addWarning("Password contains a common dictionary word.");
                    return 5;
                }
            }
        }

        // Check for name patterns, dates
        if (lower.matches(".*\\d{4}.*") && lower.length() < 10) {
            r.addSuggestion("Avoid year numbers — they're easily guessed.");
            return 12;
        }

        return 20;  // no dictionary words found
    }

    // ------------------------------------------------------------------ //
    //  5. Shannon Entropy (max 20 pts)
    // ------------------------------------------------------------------ //

    private static int scoreEntropy(String pw, PasswordStrengthResult r) {
        if (pw.isEmpty()) return 0;
        Map<Character, Integer> freq = new HashMap<>();
        for (char c : pw.toCharArray()) freq.merge(c, 1, Integer::sum);

        double entropy = 0;
        int len = pw.length();
        for (int count : freq.values()) {
            double p = (double) count / len;
            entropy -= p * (Math.log(p) / Math.log(2));
        }
        // Effective entropy: bits per char × length
        double totalBits = entropy * len;

        if (totalBits < 28) { r.addSuggestion("Password has very low entropy — too predictable."); return 2; }
        if (totalBits < 36) return 8;
        if (totalBits < 50) return 14;
        if (totalBits < 65) return 18;
        return 20;
    }

    // ------------------------------------------------------------------ //
    //  Data Loading
    // ------------------------------------------------------------------ //

    private static void loadCommonPasswords() {
        // Top common passwords / dictionary words seeded inline
        // In production: load from resources/common_passwords.txt
        String[] commons = {
            "password","123456","password1","12345678","qwerty","abc123",
            "monkey","1234567","letmein","trustno1","dragon","baseball",
            "iloveyou","master","sunshine","ashley","bailey","passw0rd",
            "shadow","123123","654321","superman","qazwsx","michael",
            "football","password123","admin","welcome","login","hello",
            "charlie","donald","password2","qwerty123","iloveyou1",
            "admin123","1qaz2wsx","1q2w3e4r","zxcvbnm","000000","111111",
            "987654321","princess","qwertyuiop","starwars","computer",
            "secret","pass","god","sex","love","money","test","access",
            "batman","ninja","mustang","jessica","654321","magic"
        };
        Collections.addAll(commonPasswords, commons);
    }

    private static void seedBreachFilter() {
        // Seed with SHA-256 hashes of known breached passwords
        // In production: load from HIBP Pwned Passwords list (SHA-1 ordered)
        String[] breachedPasswords = {
            "password","123456","qwerty","abc123","letmein","monkey",
            "1234567890","password1","iloveyou","admin","welcome","dragon",
            "master","sunshine","princess","admin123","passw0rd","shadow"
        };
        for (String bp : breachedPasswords) {
            breachFilter.add(CryptoUtil.sha256(bp));
        }
    }
}

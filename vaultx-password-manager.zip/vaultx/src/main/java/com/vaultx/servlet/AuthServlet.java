package com.vaultx.servlet;

import com.google.gson.Gson;
import com.vaultx.crypto.CryptoUtil;
import com.vaultx.model.LoginEvent;
import com.vaultx.model.User;
import com.vaultx.service.EmailService;
import com.vaultx.service.LoginTracker;
import com.vaultx.util.DatabaseManager;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.mindrot.jbcrypt.BCrypt;

import java.io.IOException;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Handles:
 *   POST /api/auth/signup  → register new user
 *   POST /api/auth/login   → authenticate + set session cookie
 *   POST /api/auth/logout  → invalidate session
 *   GET  /api/auth/me      → return current user info
 */
@WebServlet("/api/auth/*")
public class AuthServlet extends HttpServlet {

    private static final Gson GSON = new Gson();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        resp.setContentType("application/json;charset=UTF-8");
        String path = req.getPathInfo();

        switch (path == null ? "" : path) {
            case "/signup" -> handleSignup(req, resp);
            case "/login"  -> handleLogin(req, resp);
            case "/logout" -> handleLogout(req, resp);
            default        -> resp.sendError(404, "Unknown auth endpoint");
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        resp.setContentType("application/json;charset=UTF-8");
        if ("/me".equals(req.getPathInfo())) handleMe(req, resp);
        else resp.sendError(404);
    }

    // ------------------------------------------------------------------ //
    //  Signup
    // ------------------------------------------------------------------ //

    private void handleSignup(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Map<String, Object> body = parseBody(req);
        String username = (String) body.get("username");
        String email    = (String) body.get("email");
        String passkey  = (String) body.get("passkey");

        // Validation
        if (isBlank(username) || isBlank(email) || isBlank(passkey)) {
            sendError(resp, 400, "username, email and passkey are required");
            return;
        }
        if (passkey.length() < 8) {
            sendError(resp, 400, "Passkey must be at least 8 characters");
            return;
        }
        if (!email.contains("@")) {
            sendError(resp, 400, "Invalid email address");
            return;
        }

        try {
            // Check existing user
            ResultSet existing = DatabaseManager.findUserByUsername(username);
            if (existing.next()) { sendError(resp, 409, "Username already taken"); return; }

            ResultSet existingEmail = DatabaseManager.findUserByEmail(email);
            if (existingEmail.next()) { sendError(resp, 409, "Email already registered"); return; }

            // Generate salt + hash passkey with BCrypt (for authentication)
            String salt         = CryptoUtil.generateSalt();
            String bcryptHash   = BCrypt.hashpw(passkey, BCrypt.gensalt(12));

            int userId = DatabaseManager.insertUser(username, email, bcryptHash, salt);
            if (userId == -1) { sendError(resp, 500, "Failed to create user"); return; }

            // Send welcome email (async-ish)
            User user = new User(username, email, bcryptHash, salt);
            user.setId(userId);
            new Thread(() -> EmailService.sendWelcomeEmail(user)).start();

            sendSuccess(resp, 201, Map.of("message", "Account created successfully", "userId", userId));

        } catch (Exception e) {
            e.printStackTrace();
            sendError(resp, 500, "Internal server error: " + e.getMessage());
        }
    }

    // ------------------------------------------------------------------ //
    //  Login
    // ------------------------------------------------------------------ //

    private void handleLogin(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Map<String, Object> body = parseBody(req);
        String username = (String) body.get("username");
        String passkey  = (String) body.get("passkey");

        if (isBlank(username) || isBlank(passkey)) {
            sendError(resp, 400, "username and passkey are required");
            return;
        }

        String ip       = req.getRemoteAddr();
        String location = resolveLocation(ip);

        try {
            ResultSet rs = DatabaseManager.findUserByUsername(username);
            if (!rs.next()) {
                // Record failed login (no user found)
                sendError(resp, 401, "Invalid username or passkey");
                return;
            }

            int    userId       = rs.getInt("id");
            String email        = rs.getString("email");
            String storedHash   = rs.getString("password_hash");
            String salt         = rs.getString("salt");

            boolean passOk = BCrypt.checkpw(passkey, storedHash);

            // Track login (success or failure) — anomaly detection runs here
            LoginEvent event = LoginTracker.recordLogin(userId, ip, location, passOk);
            User user = new User(username, email, storedHash, salt);
            user.setId(userId);

            // Persist event to DB
            DatabaseManager.insertLoginEvent(userId, event.getTimestamp(), ip, location,
                    passOk, event.getRiskScore(), event.getRiskReason(), event.isAlertSent());

            // Send alert email if flagged
            if (event.isAlertSent()) {
                new Thread(() -> EmailService.sendLoginAlert(user, event)).start();
            }

            if (!passOk) {
                sendError(resp, 401, "Invalid username or passkey");
                return;
            }

            // Create session
            String token = UUID.randomUUID().toString().replace("-", "") +
                           UUID.randomUUID().toString().replace("-", "");
            DatabaseManager.insertSession(token, userId, ip);

            // Set httpOnly session cookie
            Cookie cookie = new Cookie("vaultx_session", token);
            cookie.setHttpOnly(true);
            cookie.setMaxAge(8 * 3600);  // 8 hours
            cookie.setPath("/");
            resp.addCookie(cookie);

            Map<String, Object> data = new HashMap<>();
            data.put("message",   "Login successful");
            data.put("userId",    userId);
            data.put("username",  username);
            data.put("riskScore", event.getRiskScore());
            if (event.getRiskScore() >= LoginTracker.ALERT_THRESHOLD) {
                data.put("alert", "Suspicious login detected! Check your email.");
            }
            sendSuccess(resp, 200, data);

        } catch (Exception e) {
            e.printStackTrace();
            sendError(resp, 500, "Internal server error");
        }
    }

    // ------------------------------------------------------------------ //
    //  Logout
    // ------------------------------------------------------------------ //

    private void handleLogout(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String token = getSessionToken(req);
        if (token != null) {
            try { DatabaseManager.deleteSession(token); } catch (Exception ignored) {}
        }
        Cookie cookie = new Cookie("vaultx_session", "");
        cookie.setMaxAge(0);
        cookie.setPath("/");
        resp.addCookie(cookie);
        sendSuccess(resp, 200, Map.of("message", "Logged out successfully"));
    }

    // ------------------------------------------------------------------ //
    //  Me
    // ------------------------------------------------------------------ //

    private void handleMe(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String token = getSessionToken(req);
        if (token == null) { sendError(resp, 401, "Not authenticated"); return; }
        try {
            ResultSet session = DatabaseManager.findSession(token);
            if (!session.next()) { sendError(resp, 401, "Session expired"); return; }
            int userId = session.getInt("user_id");
            // Quick user lookup (use a simple direct query here)
            java.sql.PreparedStatement ps = DatabaseManager.getConnection()
                    .prepareStatement("SELECT id, username, email, created_at FROM users WHERE id = ?");
            ps.setInt(1, userId);
            ResultSet user = ps.executeQuery();
            if (!user.next()) { sendError(resp, 404, "User not found"); return; }
            sendSuccess(resp, 200, Map.of(
                    "userId",   user.getInt("id"),
                    "username", user.getString("username"),
                    "email",    user.getString("email")
            ));
        } catch (Exception e) {
            sendError(resp, 500, "Server error");
        }
    }

    // ------------------------------------------------------------------ //
    //  Helpers
    // ------------------------------------------------------------------ //

    private String getSessionToken(HttpServletRequest req) {
        if (req.getCookies() == null) return null;
        for (Cookie c : req.getCookies()) {
            if ("vaultx_session".equals(c.getName())) return c.getValue();
        }
        return null;
    }

    private String resolveLocation(String ip) {
        // In production: use ip-api.com or MaxMind GeoLite2
        if ("127.0.0.1".equals(ip) || "0:0:0:0:0:0:0:1".equals(ip)) return "Localhost, Local";
        return "Unknown, Unknown";
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> parseBody(HttpServletRequest req) throws IOException {
        return GSON.fromJson(req.getReader(), Map.class);
    }

    private boolean isBlank(String s) { return s == null || s.isBlank(); }

    private void sendSuccess(HttpServletResponse resp, int status, Object data) throws IOException {
        resp.setStatus(status);
        resp.getWriter().write(GSON.toJson(data));
    }

    private void sendError(HttpServletResponse resp, int status, String msg) throws IOException {
        resp.setStatus(status);
        resp.getWriter().write(GSON.toJson(Map.of("error", msg)));
    }
}

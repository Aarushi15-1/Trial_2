package com.vaultx.service;

import com.vaultx.model.PasswordStrengthResult;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * ============================================================
 * PASSWORD GENERATOR
 * ============================================================
 * Generates cryptographically secure random passwords.
 *
 * Algorithm:
 *   1. Guarantee at least one char from each required charset
 *   2. Fill remainder from combined charset
 *   3. Fisher-Yates shuffle (O(n)) for uniform distribution
 *   4. Verify strength ≥ 70 — regenerate if below threshold
 *
 * Also provides weak-password suggestions via suggest().
 * ============================================================
 */
public class PasswordGenerator {

    private static final String LOWERCASE = "abcdefghijklmnopqrstuvwxyz";
    private static final String UPPERCASE = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private static final String DIGITS    = "0123456789";
    private static final String SYMBOLS   = "!@#$%^&*()-_=+[]{}|;:,.<>?";

    // Avoid ambiguous chars (0, O, l, 1, I) for readability
    private static final String UNAMBIGUOUS_LOWER   = "abcdefghjkmnpqrstuvwxyz";
    private static final String UNAMBIGUOUS_UPPER   = "ABCDEFGHJKMNPQRSTUVWXYZ";
    private static final String UNAMBIGUOUS_DIGITS  = "23456789";

    private static final SecureRandom RNG = new SecureRandom();

    // ------------------------------------------------------------------ //
    //  Generate
    // ------------------------------------------------------------------ //

    /** Generate a strong random password of given length (min 8, max 128). */
    public static String generate(int length) {
        return generate(length, true, true, true, true, false);
    }

    /**
     * Full control over character sets.
     * @param avoidAmbiguous  exclude chars like 0/O, l/1/I
     */
    public static String generate(int length, boolean useLower, boolean useUpper,
                                   boolean useDigits, boolean useSymbols,
                                   boolean avoidAmbiguous) {
        length = Math.max(8, Math.min(128, length));

        String lower   = avoidAmbiguous ? UNAMBIGUOUS_LOWER  : LOWERCASE;
        String upper   = avoidAmbiguous ? UNAMBIGUOUS_UPPER  : UPPERCASE;
        String digits  = avoidAmbiguous ? UNAMBIGUOUS_DIGITS : DIGITS;

        // Build combined charset
        StringBuilder charsetBuilder = new StringBuilder();
        List<Character> guaranteed   = new ArrayList<>();

        if (useLower)   { charsetBuilder.append(lower);   guaranteed.add(randomFrom(lower)); }
        if (useUpper)   { charsetBuilder.append(upper);   guaranteed.add(randomFrom(upper)); }
        if (useDigits)  { charsetBuilder.append(digits);  guaranteed.add(randomFrom(digits)); }
        if (useSymbols) { charsetBuilder.append(SYMBOLS); guaranteed.add(randomFrom(SYMBOLS)); }

        String charset = charsetBuilder.toString();
        if (charset.isEmpty()) charset = lower + upper + digits;  // fallback

        // Fill password list
        List<Character> pwChars = new ArrayList<>(guaranteed);
        int remaining = length - guaranteed.size();
        for (int i = 0; i < remaining; i++) {
            pwChars.add(randomFrom(charset));
        }

        // Fisher-Yates shuffle
        for (int i = pwChars.size() - 1; i > 0; i--) {
            int j = RNG.nextInt(i + 1);
            char tmp = pwChars.get(i);
            pwChars.set(i, pwChars.get(j));
            pwChars.set(j, tmp);
        }

        StringBuilder sb = new StringBuilder();
        for (char c : pwChars) sb.append(c);
        String candidate = sb.toString();

        // Verify strength — regenerate up to 5x if too weak
        PasswordStrengthResult result = PasswordAnalyser.analyse(candidate);
        if (result.getScore() < 70 && length >= 12) {
            return generate(length, useLower, useUpper, useDigits, useSymbols, avoidAmbiguous);
        }
        return candidate;
    }

    // ------------------------------------------------------------------ //
    //  Passphrase Generator  (4–6 random words, more memorable)
    // ------------------------------------------------------------------ //

    public static String generatePassphrase(int wordCount) {
        wordCount = Math.max(4, Math.min(8, wordCount));
        String[] words = {
            "correct","horse","battery","staple","purple","monkey","dragon",
            "window","castle","river","sunset","mountain","forest","ocean",
            "thunder","silver","golden","crystal","shadow","falcon","tiger",
            "marble","granite","cobalt","nebula","quartz","velvet","prism",
            "cipher","vertex","spiral","bridge","harbor","lantern","eclipse"
        };
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < wordCount; i++) {
            if (i > 0) sb.append('-');
            sb.append(words[RNG.nextInt(words.length)]);
        }
        // Append random digits + symbol for extra strength
        sb.append(RNG.nextInt(900) + 100);
        sb.append(SYMBOLS.charAt(RNG.nextInt(SYMBOLS.length())));
        return sb.toString();
    }

    // ------------------------------------------------------------------ //
    //  Suggestions  (called when user's password is weak)
    // ------------------------------------------------------------------ //

    public static List<String> suggest(int targetLength, int count) {
        List<String> suggestions = new ArrayList<>();
        int len = Math.max(targetLength, 16);
        // Mix of random passwords and passphrases
        for (int i = 0; i < count - 1; i++) suggestions.add(generate(len));
        suggestions.add(generatePassphrase(4));
        return suggestions;
    }

    // ------------------------------------------------------------------ //
    //  Helper
    // ------------------------------------------------------------------ //

    private static char randomFrom(String charset) {
        return charset.charAt(RNG.nextInt(charset.length()));
    }
}

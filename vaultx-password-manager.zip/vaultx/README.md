# 🔐 VaultX — DSA-Powered Password Manager

> A full-stack, production-grade password manager built in Java with heavy use of Data Structures & Algorithms.
> Every core feature is backed by a hand-implemented DSA rather than a library.

---

## 📐 Architecture Overview

```
vaultx/
├── src/main/java/com/vaultx/
│   ├── dsa/
│   │   ├── BloomFilter.java       ← Breach detection, phishing fast-path  O(k)
│   │   ├── AVLTree.java           ← Login history store (sorted by time)  O(log n)
│   │   ├── MinHeap.java           ← Anomaly priority queue                O(log n)
│   │   ├── HashTable.java         ← Vault entry cache (separate chaining) O(1) avg
│   │   └── Trie.java              ← Phishing domain blocklist + typosquat O(L)
│   ├── crypto/
│   │   └── CryptoUtil.java        ← SHA-256, AES-256-GCM, PBKDF2, ECDSA
│   ├── model/
│   │   ├── User.java
│   │   ├── PasswordEntry.java
│   │   ├── LoginEvent.java
│   │   └── PasswordStrengthResult.java
│   ├── service/
│   │   ├── PasswordAnalyser.java  ← 5-dimension scorer + Bloom breach check
│   │   ├── PasswordGenerator.java ← SecureRandom + Fisher-Yates shuffle
│   │   ├── PhishingDetector.java  ← Trie + Bloom + heuristics + ECDSA
│   │   ├── LoginTracker.java      ← AVL + MinHeap + anomaly scoring
│   │   └── EmailService.java      ← SMTP alert emails
│   ├── servlet/
│   │   ├── AuthServlet.java       ← POST /api/auth/{signup,login,logout}
│   │   ├── VaultServlet.java      ← CRUD /api/vault
│   │   └── ToolsServlet.java      ← /api/tools/{analyse,generate,phishing,login-history}
│   └── util/
│       ├── DatabaseManager.java   ← SQLite via JDBC
│       ├── CorsFilter.java
│       └── SecurityFilter.java
├── src/main/webapp/
│   ├── index.html                 ← Full SPA frontend (dark cyberpunk UI)
│   └── WEB-INF/web.xml
├── src/test/java/com/vaultx/
│   └── VaultXTests.java           ← JUnit 5 tests for all DSAs + crypto
└── pom.xml
```

---

## 🧬 DSA Reference Table

| Feature | Data Structure | Time Complexity | Why This DSA? |
|---|---|---|---|
| Breach detection (passwords) | **Bloom Filter** | O(k) insert/query | Space-efficient set membership; no false negatives |
| Phishing domain fast-path | **Bloom Filter** | O(k) | Skip Trie lookup for clearly safe URLs |
| Phishing blocklist | **Trie** | O(L) | Prefix-based typosquat detection + exact match |
| Login history store | **AVL Tree** | O(log n) | Sorted by timestamp; O(log n + k) range queries |
| Anomaly priority queue | **Min-Heap** | O(log n) | Surface K most suspicious logins efficiently |
| Vault cache | **Hash Table** | O(1) amortized | Per-user prefix scan; custom double-hash + Wang mix |
| Passphrase shuffle | **Fisher-Yates** | O(n) | Provably uniform random permutation |
| Levenshtein distance | **DP Table** | O(m × n) | Edit-distance typosquat detection in Trie |

---

## 🔐 Cryptography

| Purpose | Algorithm | Details |
|---|---|---|
| Password hashing (breach check) | **SHA-256 + salt** | `SHA-256(salt ‖ password)` — 32-byte random salt per user |
| Master passkey storage | **BCrypt** | Work factor 12 — rainbow table + brute-force resistant |
| Key derivation | **PBKDF2WithHmacSHA256** | 310,000 iterations (OWASP 2023) → 256-bit AES key |
| Vault encryption | **AES-256-GCM** | 12-byte IV, 128-bit auth tag — authenticated encryption |
| URL signature | **ECDSA P-256** | Domain fingerprint signed by VaultX CA; detects DNS hijacking |

### Why SHA-256 with salting prevents rainbow tables

```
Without salt:  SHA256("password") = 5e88… (same for EVERY user)
With salt:     SHA256("X7mK…||password") = a9f3…  ← unique per user

An attacker who steals the DB cannot use precomputed tables.
They must hash each guess against each user's unique salt → 10^9× slower.
```

---

## 🚀 Step-by-Step GitHub Setup Guide

### Prerequisites

| Tool | Version | Download |
|---|---|---|
| Java JDK | 17+ | https://adoptium.net |
| Apache Maven | 3.9+ | https://maven.apache.org |
| Apache Tomcat | 10.1+ | https://tomcat.apache.org |
| Git | Any | https://git-scm.com |

---

### Step 1 — Clone the Repository

```bash
git clone https://github.com/YOUR_USERNAME/vaultx-password-manager.git
cd vaultx-password-manager
```

---

### Step 2 — Verify Prerequisites

```bash
java -version
# java version "17.0.x" or higher

mvn -version
# Apache Maven 3.9.x

# Check JAVA_HOME is set
echo $JAVA_HOME        # Linux/Mac
echo %JAVA_HOME%       # Windows
```

If JAVA_HOME is not set:
```bash
# Linux/Mac (add to ~/.bashrc or ~/.zshrc)
export JAVA_HOME=/usr/lib/jvm/java-17-openjdk
export PATH=$JAVA_HOME/bin:$PATH

# Windows: System Properties → Environment Variables → New
# Variable: JAVA_HOME   Value: C:\Program Files\Eclipse Adoptium\jdk-17...
```

---

### Step 3 — Configure Email Alerts (Optional)

Edit `src/main/java/com/vaultx/service/EmailService.java` OR set environment variables:

```bash
# Linux/Mac
export SMTP_HOST=smtp.gmail.com
export SMTP_PORT=587
export SMTP_USER=your-email@gmail.com
export SMTP_PASS=your-app-password   # Gmail App Password, NOT your real password

# Windows PowerShell
$env:SMTP_HOST = "smtp.gmail.com"
$env:SMTP_PORT = "587"
$env:SMTP_USER = "your-email@gmail.com"
$env:SMTP_PASS = "your-app-password"
```

**Getting a Gmail App Password:**
1. Go to https://myaccount.google.com/security
2. Enable 2-Step Verification
3. Search "App passwords" → Create one for "Mail"
4. Use the 16-character code as `SMTP_PASS`

> If you skip this step, the app works fine — alerts just won't be sent by email.

---

### Step 4 — Build the Project

```bash
# From the project root (where pom.xml is)
mvn clean package -DskipTests

# Build WITH tests (requires all services to be wired; skip on first build)
mvn clean package
```

Successful build output:
```
[INFO] BUILD SUCCESS
[INFO] Total time: 12.345 s
[INFO] Finished at: ...
```

The WAR file is created at:
```
target/vaultx-password-manager-1.0.0.war
```

---

### Step 5 — Run Tests

```bash
mvn test
```

Expected output:
```
[INFO] Tests run: 22, Failures: 0, Errors: 0, Skipped: 0
[INFO] BUILD SUCCESS
```

Test coverage:
- BloomFilter (false negatives = 0, FP rate < 5%)
- AVLTree (insert, inorder sort, range query)
- MinHeap (extraction order)
- HashTable (CRUD + prefix scan)
- Trie (exact match, IP heuristic, brand spoof)
- CryptoUtil (SHA-256 with salt, AES-GCM roundtrip, ECDSA)
- PasswordAnalyser (weak/strong/empty)
- PasswordGenerator (length, strength, passphrase)
- PhishingDetector (safe URL, blocklist, digital signature)

---

### Step 6 — Deploy to Tomcat

#### Option A: Maven Tomcat Plugin (simplest for development)

```bash
mvn tomcat7:run
```

Then open: **http://localhost:8080**

#### Option B: Manual Tomcat Deployment

```bash
# 1. Download and extract Tomcat 10.1
#    https://tomcat.apache.org/download-10.cgi

# 2. Copy the WAR file
cp target/vaultx-password-manager-1.0.0.war /path/to/tomcat/webapps/ROOT.war

# 3. Start Tomcat
# Linux/Mac:
/path/to/tomcat/bin/startup.sh

# Windows:
C:\tomcat\bin\startup.bat

# 4. Open browser
#    http://localhost:8080
```

#### Option C: Docker (production-ready)

```bash
# Build Docker image
docker build -t vaultx:1.0 .

# Run container
docker run -p 8080:8080 \
  -e SMTP_HOST=smtp.gmail.com \
  -e SMTP_USER=your@gmail.com \
  -e SMTP_PASS=your-app-password \
  -v $(pwd)/data:/app/data \
  vaultx:1.0
```

Create a `Dockerfile` in the project root:
```dockerfile
FROM tomcat:10.1-jdk17
COPY target/vaultx-password-manager-1.0.0.war /usr/local/tomcat/webapps/ROOT.war
EXPOSE 8080
CMD ["catalina.sh", "run"]
```

---

### Step 7 — First Use

1. Open **http://localhost:8080**
2. Click **Create Account**
3. Enter username, email, and a strong master passkey
4. You are automatically signed in and redirected to your vault
5. Add your first password entry using the **+ Add Password** button
6. Your master passkey is required to decrypt individual passwords

> ⚠️ **Important:** VaultX does NOT store your master passkey anywhere.
> If you forget it, your encrypted passwords cannot be recovered.
> Keep it safe.

---

### Step 8 — Publishing to GitHub

```bash
# 1. Initialize git (if not cloned)
git init
git add .
git commit -m "feat: initial VaultX password manager"

# 2. Create repo on GitHub.com (no README, no .gitignore)

# 3. Push
git remote add origin https://github.com/YOUR_USERNAME/vaultx-password-manager.git
git branch -M main
git push -u origin main
```

**Important — add a `.gitignore`:**

```
# .gitignore
target/
*.class
*.war
*.db          ← NEVER commit your database (contains encrypted passwords)
*.log
.env
*.iml
.idea/
.DS_Store
```

---

## 📡 API Reference

### Auth
| Method | Endpoint | Body | Response |
|---|---|---|---|
| POST | `/api/auth/signup` | `{username, email, passkey}` | `{userId, message}` |
| POST | `/api/auth/login`  | `{username, passkey}`        | `{userId, username, riskScore}` |
| POST | `/api/auth/logout` | — | `{message}` |
| GET  | `/api/auth/me`     | — | `{userId, username, email}` |

### Vault
| Method | Endpoint | Notes |
|---|---|---|
| GET  | `/api/vault`              | List all entries (no plaintext passwords) |
| POST | `/api/vault`              | Body: `{siteUrl, siteName, siteUsername, password, masterKey, category}` |
| DELETE | `/api/vault/{id}`       | Delete entry |
| GET  | `/api/vault/{id}/decrypt` | Query: `?masterKey=xxx` → returns `{password}` |

### Tools
| Method | Endpoint | Body / Params |
|---|---|---|
| POST | `/api/tools/analyse`       | `{password}` → full strength analysis |
| POST | `/api/tools/generate`      | `{length, useSymbols, useDigits, useUpper, useLower, passphrase}` |
| POST | `/api/tools/phishing`      | `{url}` → `{isPhishing, threatLevel, message}` |
| GET  | `/api/tools/login-history` | Returns last 50 login events |

---

## 🔍 Key Algorithm Deep-Dives

### Bloom Filter — Breach Detection

```
Insert "password":
  h1("password") % m = 142,731  → set bit
  h2("password") % m = 88,405   → set bit
  ...
  h7("password") % m = 601,234  → set bit

Query "password":
  All 7 bits set? → mightContain = TRUE  (probable positive)

Query "correcthorsebatterystaple":
  Bit 304,811 not set? → mightContain = FALSE  (definite negative)

False positive rate ≈ (1 - e^(-kn/m))^k
With m=958,505, k=7, n=100,000: FP ≈ 1.0%
```

### AVL Tree — Balanced Login History

```
Insert timestamps: 5000, 1000, 8000, 3000, 7000

After balancing:
         5000
        /    \
     1000    8000
       \    /
      3000 7000

Height = 3  (vs 5 for unbalanced BST)
All operations guaranteed O(log n)
```

### Trie — Phishing Detection

```
Insert: "paypa1.com"
p → a → y → p → a → 1 → . → c → o → m [✓ end, level=2]

Query: "paypa1.com" → traverse → hit end node → BLOCKED

Typosquat query: "paypa2.com"
  - prefix "paypa" matches → levenshtein("paypa2.com","paypa1.com") = 1
  - Within edit distance 2 → SUSPICIOUS
```

---

## 🏗 Production Checklist

- [ ] Switch `vaultx.db` to PostgreSQL or MySQL
- [ ] Add HTTPS (Tomcat + Let's Encrypt or nginx reverse proxy)
- [ ] Set `Secure` flag on session cookies
- [ ] Tighten CSP headers in SecurityFilter
- [ ] Load HIBP Pwned Passwords list (https://haveibeenpwned.com/Passwords) into BloomFilter
- [ ] Load comprehensive phishing domain list (PhishTank, OpenPhish) into Trie
- [ ] Add rate limiting to `/api/auth/login` (max 5 attempts / 15 min)
- [ ] Implement TOTP / WebAuthn 2FA
- [ ] Add audit logging to a separate append-only table
- [ ] Set `SMTP_*` environment variables in production server

---

## 📚 Dependencies

| Library | Version | Purpose |
|---|---|---|
| Jakarta Servlet API | 6.0 | HTTP servlet container |
| Gson | 2.10.1 | JSON serialization |
| SQLite JDBC | 3.45.1 | Embedded database |
| Jakarta Mail | 2.0.1 | SMTP email alerts |
| JBCrypt | 0.4 | BCrypt for passkey storage |
| SLF4J + Logback | latest | Logging |
| JUnit 5 | 5.10.2 | Unit testing |

All DSA (BloomFilter, AVLTree, MinHeap, HashTable, Trie) are **hand-implemented** — no external libraries.

---

## 📄 License

MIT License — free for personal and educational use.

---

*Built with ❤️ and lots of DSA*

package com.vaultx.service;

import com.vaultx.model.LoginEvent;
import com.vaultx.model.User;
import jakarta.mail.*;
import jakarta.mail.internet.*;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Properties;

/**
 * ============================================================
 * EMAIL SERVICE
 * ============================================================
 * Sends security alerts via SMTP (Gmail / any SMTP provider).
 *
 * Configure SMTP settings in config.properties:
 *   mail.smtp.host=smtp.gmail.com
 *   mail.smtp.port=587
 *   mail.from=vaultx-alerts@yourdomain.com
 *   mail.password=your_app_password
 * ============================================================
 */
public class EmailService {

    // Override these with env vars / config in production
    private static final String SMTP_HOST = System.getenv().getOrDefault("SMTP_HOST", "smtp.gmail.com");
    private static final String SMTP_PORT = System.getenv().getOrDefault("SMTP_PORT", "587");
    private static final String FROM_EMAIL = System.getenv().getOrDefault("SMTP_USER", "vaultx@example.com");
    private static final String FROM_PASS  = System.getenv().getOrDefault("SMTP_PASS", "changeme");

    // ------------------------------------------------------------------ //
    //  Login Alert
    // ------------------------------------------------------------------ //

    public static void sendLoginAlert(User user, LoginEvent event) {
        String subject = "🔐 VaultX Security Alert: Suspicious Login Detected";

        String time = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss z")
                .format(Instant.ofEpochMilli(event.getTimestamp()).atZone(ZoneId.of("UTC")));

        String body = """
                <html><body style="font-family: 'Segoe UI', sans-serif; background:#0a0a0a; color:#e0e0e0; padding:32px;">
                <div style="max-width:600px; margin:auto; background:#111; border:1px solid #00ff88; border-radius:12px; padding:32px;">
                  <h1 style="color:#00ff88; font-size:24px; margin-bottom:8px;">⚠ Suspicious Login Alert</h1>
                  <p style="color:#aaa;">VaultX detected unusual login activity on your account.</p>
                  <hr style="border-color:#222;"/>
                  <table style="width:100%%; color:#ccc; margin:16px 0;">
                    <tr><td style="padding:8px; color:#888;">User</td><td style="color:#fff;">%s</td></tr>
                    <tr><td style="padding:8px; color:#888;">Time</td><td style="color:#fff;">%s</td></tr>
                    <tr><td style="padding:8px; color:#888;">IP Address</td><td style="color:#fff;">%s</td></tr>
                    <tr><td style="padding:8px; color:#888;">Location</td><td style="color:#fff;">%s</td></tr>
                    <tr><td style="padding:8px; color:#888;">Risk Score</td><td style="color:#ff4444;">%.0f%%</td></tr>
                    <tr><td style="padding:8px; color:#888;">Reason</td><td style="color:#ffaa00;">%s</td></tr>
                    <tr><td style="padding:8px; color:#888;">Status</td><td style="color:%s;">%s</td></tr>
                  </table>
                  <hr style="border-color:#222;"/>
                  <p style="color:#aaa;">If this was you, you can ignore this email.<br>
                  If this was NOT you, <strong style="color:#ff4444;">change your passkey immediately</strong> and review your vault.</p>
                  <a href="http://localhost:8080/security" style="display:inline-block; margin-top:16px; padding:12px 24px;
                     background:#00ff88; color:#000; font-weight:bold; border-radius:8px; text-decoration:none;">
                     Review Security Settings
                  </a>
                </div></body></html>
                """.formatted(
                user.getUsername(), time, event.getIpAddress(), event.getLocation(),
                event.getRiskScore() * 100, event.getRiskReason(),
                event.isSuccessful() ? "#00ff88" : "#ff4444",
                event.isSuccessful() ? "Successful" : "Failed"
        );

        sendHtmlEmail(user.getEmail(), subject, body);
    }

    // ------------------------------------------------------------------ //
    //  Welcome Email
    // ------------------------------------------------------------------ //

    public static void sendWelcomeEmail(User user) {
        String subject = "🔐 Welcome to VaultX – Your Secure Password Manager";
        String body = """
                <html><body style="font-family: 'Segoe UI', sans-serif; background:#0a0a0a; color:#e0e0e0; padding:32px;">
                <div style="max-width:600px; margin:auto; background:#111; border:1px solid #00ff88; border-radius:12px; padding:32px;">
                  <h1 style="color:#00ff88;">Welcome to VaultX, %s!</h1>
                  <p>Your vault has been created. Here's what you get:</p>
                  <ul style="color:#aaa; line-height:2;">
                    <li>🔒 AES-256 encrypted password storage</li>
                    <li>💪 Real-time password strength analysis</li>
                    <li>🎲 Secure random password generator</li>
                    <li>🎣 Phishing URL detector</li>
                    <li>📍 Login anomaly tracking & alerts</li>
                  </ul>
                  <a href="http://localhost:8080/login" style="display:inline-block; margin-top:16px; padding:12px 24px;
                     background:#00ff88; color:#000; font-weight:bold; border-radius:8px; text-decoration:none;">
                     Open My Vault
                  </a>
                </div></body></html>
                """.formatted(user.getUsername());
        sendHtmlEmail(user.getEmail(), subject, body);
    }

    // ------------------------------------------------------------------ //
    //  Core Send
    // ------------------------------------------------------------------ //

    private static void sendHtmlEmail(String to, String subject, String htmlBody) {
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", SMTP_HOST);
        props.put("mail.smtp.port", SMTP_PORT);
        props.put("mail.smtp.ssl.protocols", "TLSv1.2");

        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(FROM_EMAIL, FROM_PASS);
            }
        });

        try {
            Message msg = new MimeMessage(session);
            msg.setFrom(new InternetAddress(FROM_EMAIL, "VaultX Security"));
            msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
            msg.setSubject(subject);
            msg.setContent(htmlBody, "text/html; charset=utf-8");
            Transport.send(msg);
            System.out.println("[EmailService] Alert sent to: " + to);
        } catch (Exception e) {
            // In production: log to monitoring system; never swallow silently
            System.err.println("[EmailService] Failed to send email: " + e.getMessage());
        }
    }
}

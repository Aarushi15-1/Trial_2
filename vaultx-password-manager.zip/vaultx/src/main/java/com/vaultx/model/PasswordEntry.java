package com.vaultx.model;

/**
 * Represents one stored credential in the vault.
 * The password field is stored as: SHA-256(salt + plaintext) → encrypted ciphertext.
 */
public class PasswordEntry {
    private int    id;
    private int    userId;
    private String siteUrl;
    private String siteName;
    private String siteUsername;
    private String encryptedPassword;   // AES-256 encrypted
    private String iv;                  // Initialization vector (base64)
    private String passwordHash;        // SHA-256(salt + plain) for breach check
    private int    strengthScore;       // 0-100
    private long   createdAt;
    private long   updatedAt;
    private String notes;               // encrypted notes
    private String category;            // e.g. "Social", "Banking", "Work"

    public PasswordEntry() {}

    public PasswordEntry(int userId, String siteUrl, String siteName,
                         String siteUsername, String encryptedPassword,
                         String iv, String passwordHash, int strengthScore) {
        this.userId            = userId;
        this.siteUrl           = siteUrl;
        this.siteName          = siteName;
        this.siteUsername      = siteUsername;
        this.encryptedPassword = encryptedPassword;
        this.iv                = iv;
        this.passwordHash      = passwordHash;
        this.strengthScore     = strengthScore;
        this.createdAt         = System.currentTimeMillis();
        this.updatedAt         = System.currentTimeMillis();
    }

    // Getters & Setters
    public int    getId()                   { return id; }
    public void   setId(int id)             { this.id = id; }
    public int    getUserId()               { return userId; }
    public void   setUserId(int u)          { this.userId = u; }
    public String getSiteUrl()              { return siteUrl; }
    public void   setSiteUrl(String s)      { this.siteUrl = s; }
    public String getSiteName()             { return siteName; }
    public void   setSiteName(String s)     { this.siteName = s; }
    public String getSiteUsername()         { return siteUsername; }
    public void   setSiteUsername(String s) { this.siteUsername = s; }
    public String getEncryptedPassword()    { return encryptedPassword; }
    public void   setEncryptedPassword(String e) { this.encryptedPassword = e; }
    public String getIv()                   { return iv; }
    public void   setIv(String iv)          { this.iv = iv; }
    public String getPasswordHash()         { return passwordHash; }
    public void   setPasswordHash(String h) { this.passwordHash = h; }
    public int    getStrengthScore()        { return strengthScore; }
    public void   setStrengthScore(int s)   { this.strengthScore = s; }
    public long   getCreatedAt()            { return createdAt; }
    public void   setCreatedAt(long t)      { this.createdAt = t; }
    public long   getUpdatedAt()            { return updatedAt; }
    public void   setUpdatedAt(long t)      { this.updatedAt = t; }
    public String getNotes()                { return notes; }
    public void   setNotes(String n)        { this.notes = n; }
    public String getCategory()             { return category; }
    public void   setCategory(String c)     { this.category = c; }
}

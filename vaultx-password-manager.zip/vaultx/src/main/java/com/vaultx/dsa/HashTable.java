package com.vaultx.dsa;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * ============================================================
 * CUSTOM HASH TABLE — Password Vault Storage
 * ============================================================
 * Separate-chaining hash table.
 * Key   = userId + ":" + site  (e.g. "u42:github.com")
 * Value = EncryptedPasswordEntry JSON blob
 *
 *   put(key, value)  → O(1) amortized
 *   get(key)         → O(1) amortized
 *   delete(key)      → O(1) amortized
 *   getAllForUser(userId) → O(n/m + k)
 *
 * Auto-resizes when load factor > 0.75 (doubles capacity, rehashes).
 * ============================================================
 */
public class HashTable<K, V> {

    private static final int    INITIAL_CAPACITY   = 64;
    private static final double LOAD_FACTOR_LIMIT  = 0.75;

    @SuppressWarnings("unchecked")
    private LinkedList<Entry<K, V>>[] buckets = new LinkedList[INITIAL_CAPACITY];
    private int capacity = INITIAL_CAPACITY;
    private int size     = 0;

    // ------------------------------------------------------------------ //
    //  Entry
    // ------------------------------------------------------------------ //
    private static class Entry<K, V> {
        K key;
        V value;
        Entry(K k, V v) { this.key = k; this.value = v; }
    }

    // ------------------------------------------------------------------ //
    //  Core Operations
    // ------------------------------------------------------------------ //

    public void put(K key, V value) {
        if ((double) size / capacity >= LOAD_FACTOR_LIMIT) resize();

        int idx = index(key);
        if (buckets[idx] == null) buckets[idx] = new LinkedList<>();

        for (Entry<K, V> e : buckets[idx]) {
            if (e.key.equals(key)) { e.value = value; return; }  // update
        }
        buckets[idx].add(new Entry<>(key, value));
        size++;
    }

    public V get(K key) {
        int idx = index(key);
        if (buckets[idx] == null) return null;
        for (Entry<K, V> e : buckets[idx]) {
            if (e.key.equals(key)) return e.value;
        }
        return null;
    }

    public boolean containsKey(K key) { return get(key) != null; }

    public V delete(K key) {
        int idx = index(key);
        if (buckets[idx] == null) return null;
        var iter = buckets[idx].iterator();
        while (iter.hasNext()) {
            Entry<K, V> e = iter.next();
            if (e.key.equals(key)) {
                iter.remove();
                size--;
                return e.value;
            }
        }
        return null;
    }

    /** Return all values whose key starts with prefix (used for user vault queries) */
    public List<V> getByKeyPrefix(String prefix) {
        List<V> result = new ArrayList<>();
        for (LinkedList<Entry<K, V>> bucket : buckets) {
            if (bucket == null) continue;
            for (Entry<K, V> e : bucket) {
                if (e.key.toString().startsWith(prefix)) result.add(e.value);
            }
        }
        return result;
    }

    public List<K> keys() {
        List<K> result = new ArrayList<>();
        for (LinkedList<Entry<K, V>> bucket : buckets) {
            if (bucket == null) continue;
            for (Entry<K, V> e : bucket) result.add(e.key);
        }
        return result;
    }

    public int  size()    { return size; }
    public boolean isEmpty() { return size == 0; }

    // ------------------------------------------------------------------ //
    //  Hashing  (polynomial rolling hash using key.hashCode())
    // ------------------------------------------------------------------ //

    private int index(K key) {
        int h = key.hashCode();
        // Spread upper bits into lower bits (Wang hash mix)
        h ^= (h >>> 16);
        h *= 0x45d9f3b;
        h ^= (h >>> 16);
        return Math.abs(h) % capacity;
    }

    // ------------------------------------------------------------------ //
    //  Resize
    // ------------------------------------------------------------------ //

    @SuppressWarnings("unchecked")
    private void resize() {
        int newCapacity = capacity * 2;
        LinkedList<Entry<K, V>>[] newBuckets = new LinkedList[newCapacity];

        for (LinkedList<Entry<K, V>> bucket : buckets) {
            if (bucket == null) continue;
            for (Entry<K, V> e : bucket) {
                int h = e.key.hashCode();
                h ^= (h >>> 16); h *= 0x45d9f3b; h ^= (h >>> 16);
                int idx = Math.abs(h) % newCapacity;
                if (newBuckets[idx] == null) newBuckets[idx] = new LinkedList<>();
                newBuckets[idx].add(e);
            }
        }
        buckets  = newBuckets;
        capacity = newCapacity;
    }

    public double loadFactor() { return (double) size / capacity; }
    public int    capacity()   { return capacity; }
}

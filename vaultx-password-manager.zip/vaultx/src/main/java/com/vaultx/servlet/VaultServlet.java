package com.vaultx.servlet;

import com.google.gson.Gson;
import com.vaultx.crypto.CryptoUtil;
import com.vaultx.model.PasswordStrengthResult;
import com.vaultx.service.PasswordAnalyser;
import com.vaultx.service.PasswordGenerator;
import com.vaultx.util.DatabaseManager;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import javax.crypto.SecretKey;
import java.io.IOException;
import java.sql.ResultSet;
import java.util.*;

/**
 * Password Vault CRUD API
 *
 *   GET    /api/vault          → list all entries for logged-in user
 *   POST   /api/vault          → add new password entry
 *   DELETE /api/vault/{id}     → delete entry
 *   GET    /api/vault/{id}/decrypt → decrypt & return plaintext password
 */
@WebServlet("/api/vault/*")
public class VaultServlet extends HttpServlet {

    private static final Gson GSON = new Gson();

    // ------------------------------------------------------------------ //
    //  GET
    // ------------------------------------------------------------------ //

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("application/json;charset=UTF-8");
        int userId = resolveUserId(req, resp);
        if (userId == -1) return;

        String pathInfo = req.getPathInfo();

        // GET /api/vault/{id}/decrypt
        if (pathInfo != null && pathInfo.endsWith("/decrypt")) {
            handleDecrypt(req, resp, userId, pathInfo);
            return;
        }

        // GET /api/vault  — list all entries
        try {
            ResultSet rs = DatabaseManager.getPasswordEntries(userId);
            List<Map<String, Object>> entries = new ArrayList<>();
            while (rs.next()) {
                Map<String, Object> entry = new LinkedHashMap<>();
                entry.put("id",            rs.getInt("id"));
                entry.put("siteUrl",       rs.getString("site_url"));
                entry.put("siteName",      rs.getString("site_name"));
                entry.put("siteUsername",  rs.getString("site_username"));
                entry.put("strengthScore", rs.getInt("strength_score"));
                entry.put("category",      rs.getString("category"));
                entry.put("createdAt",     rs.getLong("created_at"));
                entry.put("updatedAt",     rs.getLong("updated_at"));
                // Never return encrypted password in list view
                entries.add(entry);
            }
            sendSuccess(resp, 200, Map.of("entries", entries, "count", entries.size()));
        } catch (Exception e) {
            sendError(resp, 500, "Failed to fetch vault: " + e.getMessage());
        }
    }

    // ------------------------------------------------------------------ //
    //  POST — add new entry
    // ------------------------------------------------------------------ //

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("application/json;charset=UTF-8");
        int userId = resolveUserId(req, resp);
        if (userId == -1) return;

        Map<String, Object> body = parseBody(req);
        String siteUrl      = (String) body.get("siteUrl");
        String siteName     = (String) body.get("siteName");
        String siteUsername = (String) body.get("siteUsername");
        String plainPw      = (String) body.get("password");
        String masterKey    = (String) body.get("masterKey");
        String category     = (String) body.getOrDefault("category", "General");
        String notes        = (String) body.getOrDefault("notes", "");

        if (isBlank(plainPw) || isBlank(masterKey)) {
            sendError(resp, 400, "password and masterKey are required");
            return;
        }

        try {
            // Retrieve user salt from DB
            String salt = getUserSalt(userId);
            if (salt == null) { sendError(resp, 404, "User not found"); return; }

            // Analyse password strength
            PasswordStrengthResult strength = PasswordAnalyser.analyse(plainPw);

            // Hash for breach check (stored, never used to reconstruct password)
            String pwHash = CryptoUtil.sha256WithSalt(plainPw, salt);

            // Encrypt with AES-256-GCM using key derived from master passkey
            SecretKey aesKey = CryptoUtil.deriveKey(masterKey, salt);
            String iv        = CryptoUtil.generateIV();
            String encrypted = CryptoUtil.encrypt(plainPw, aesKey, iv);

            int id = DatabaseManager.insertPasswordEntry(
                    userId, siteUrl, siteName, siteUsername,
                    encrypted, iv, pwHash,
                    strength.getScore(), category, notes
            );

            // Build suggestions if password is weak
            List<String> suggestions = new ArrayList<>();
            if (strength.getScore() < 60) {
                suggestions = PasswordGenerator.suggest(
                        plainPw.length() < 16 ? 16 : plainPw.length(), 3);
            }

            Map<String, Object> result = new LinkedHashMap<>();
            result.put("id",            id);
            result.put("strengthScore", strength.getScore());
            result.put("strengthGrade", strength.getGrade());
            result.put("breached",      strength.isBreached());
            result.put("warnings",      strength.getWarnings());
            result.put("suggestions",   suggestions);
            sendSuccess(resp, 201, result);

        } catch (Exception e) {
            e.printStackTrace();
            sendError(resp, 500, "Failed to store password: " + e.getMessage());
        }
    }

    // ------------------------------------------------------------------ //
    //  DELETE
    // ------------------------------------------------------------------ //

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("application/json;charset=UTF-8");
        int userId = resolveUserId(req, resp);
        if (userId == -1) return;

        String pathInfo = req.getPathInfo();
        if (pathInfo == null || pathInfo.length() < 2) {
            sendError(resp, 400, "Entry ID required");
            return;
        }

        try {
            int entryId = Integer.parseInt(pathInfo.substring(1));
            boolean deleted = DatabaseManager.deletePasswordEntry(entryId, userId);
            if (deleted) sendSuccess(resp, 200, Map.of("message", "Entry deleted"));
            else         sendError(resp, 404, "Entry not found");
        } catch (NumberFormatException e) {
            sendError(resp, 400, "Invalid entry ID");
        } catch (Exception e) {
            sendError(resp, 500, "Delete failed");
        }
    }

    // ------------------------------------------------------------------ //
    //  Decrypt
    // ------------------------------------------------------------------ //

    private void handleDecrypt(HttpServletRequest req, HttpServletResponse resp,
                                int userId, String pathInfo) throws IOException {
        String masterKey = req.getParameter("masterKey");
        if (isBlank(masterKey)) { sendError(resp, 400, "masterKey required"); return; }

        try {
            // Parse entry ID from path: /123/decrypt
            String[] parts = pathInfo.split("/");
            int entryId = Integer.parseInt(parts[1]);

            ResultSet rs = DatabaseManager.getConnection().prepareStatement(
                "SELECT * FROM password_entries WHERE id = " + entryId + " AND user_id = " + userId
            ).executeQuery();

            if (!rs.next()) { sendError(resp, 404, "Entry not found"); return; }

            String encrypted = rs.getString("encrypted_password");
            String iv        = rs.getString("iv");
            String salt      = getUserSalt(userId);

            SecretKey aesKey  = CryptoUtil.deriveKey(masterKey, salt);
            String plaintext  = CryptoUtil.decrypt(encrypted, aesKey, iv);

            sendSuccess(resp, 200, Map.of("password", plaintext));

        } catch (Exception e) {
            sendError(resp, 500, "Decryption failed — check your master key");
        }
    }

    // ------------------------------------------------------------------ //
    //  Auth helper
    // ------------------------------------------------------------------ //

    private int resolveUserId(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String token = null;
        if (req.getCookies() != null) {
            for (Cookie c : req.getCookies()) {
                if ("vaultx_session".equals(c.getName())) { token = c.getValue(); break; }
            }
        }
        if (token == null) { sendError(resp, 401, "Not authenticated"); return -1; }
        try {
            ResultSet session = DatabaseManager.findSession(token);
            if (!session.next()) { sendError(resp, 401, "Session expired"); return -1; }
            return session.getInt("user_id");
        } catch (Exception e) {
            sendError(resp, 500, "Session error");
            return -1;
        }
    }

    private String getUserSalt(int userId) {
        try {
            ResultSet rs = DatabaseManager.getConnection().prepareStatement(
                    "SELECT salt FROM users WHERE id = " + userId).executeQuery();
            return rs.next() ? rs.getString("salt") : null;
        } catch (Exception e) { return null; }
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> parseBody(HttpServletRequest req) throws IOException {
        return GSON.fromJson(req.getReader(), Map.class);
    }

    private boolean isBlank(String s) { return s == null || s.isBlank(); }

    private void sendSuccess(HttpServletResponse resp, int status, Object data) throws IOException {
        resp.setStatus(status);
        resp.getWriter().write(GSON.toJson(data));
    }

    private void sendError(HttpServletResponse resp, int status, String msg) throws IOException {
        resp.setStatus(status);
        resp.getWriter().write(GSON.toJson(Map.of("error", msg)));
    }
}

package com.vaultx.model;

/**
 * Records a single login attempt — stored in AVL Tree + MinHeap.
 */
public class LoginEvent {
    private int    id;
    private int    userId;
    private long   timestamp;      // epoch millis — AVL tree key
    private String ipAddress;
    private String location;       // "City, Country" from IP geolocation
    private boolean successful;
    private double  riskScore;     // 0.0 (normal) – 1.0 (highly suspicious)
    private String  riskReason;    // human-readable explanation
    private boolean alertSent;

    public LoginEvent() {}

    public LoginEvent(int userId, long timestamp, String ipAddress,
                      String location, boolean successful) {
        this.userId     = userId;
        this.timestamp  = timestamp;
        this.ipAddress  = ipAddress;
        this.location   = location;
        this.successful = successful;
        this.riskScore  = 0.0;
        this.alertSent  = false;
    }

    // Getters & Setters
    public int     getId()              { return id; }
    public void    setId(int id)        { this.id = id; }
    public int     getUserId()          { return userId; }
    public void    setUserId(int u)     { this.userId = u; }
    public long    getTimestamp()       { return timestamp; }
    public void    setTimestamp(long t) { this.timestamp = t; }
    public String  getIpAddress()       { return ipAddress; }
    public void    setIpAddress(String ip) { this.ipAddress = ip; }
    public String  getLocation()        { return location; }
    public void    setLocation(String l){ this.location = l; }
    public boolean isSuccessful()       { return successful; }
    public void    setSuccessful(boolean s) { this.successful = s; }
    public double  getRiskScore()       { return riskScore; }
    public void    setRiskScore(double r) { this.riskScore = r; }
    public String  getRiskReason()      { return riskReason; }
    public void    setRiskReason(String r) { this.riskReason = r; }
    public boolean isAlertSent()        { return alertSent; }
    public void    setAlertSent(boolean a) { this.alertSent = a; }

    @Override
    public String toString() {
        return "LoginEvent{userId=" + userId + ", ts=" + timestamp +
                ", ip=" + ipAddress + ", loc=" + location +
                ", ok=" + successful + ", risk=" + String.format("%.2f", riskScore) + "}";
    }
}

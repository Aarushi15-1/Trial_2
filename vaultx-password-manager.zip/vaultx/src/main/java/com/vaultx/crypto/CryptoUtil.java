package com.vaultx.crypto;

import javax.crypto.*;
import javax.crypto.spec.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.util.Base64;

/**
 * ============================================================
 * CRYPTOGRAPHIC UTILITIES
 * ============================================================
 * All cryptographic primitives used by VaultX.
 *
 * 1. SHA-256 with per-user salt → password hashing (breach check)
 * 2. AES-256-GCM  → symmetric vault encryption
 * 3. PBKDF2WithHmacSHA256 → key derivation from master passkey
 * 4. Secure random salt/IV generation
 *
 * Rainbow-table prevention:
 *   - 32-byte random salt per user, stored in DB
 *   - SHA-256(salt || password) produces unique hash
 *   - Even identical passwords produce different hashes
 * ============================================================
 */
public class CryptoUtil {

    private static final int    SALT_BYTES       = 32;
    private static final int    IV_BYTES         = 12;    // GCM standard
    private static final int    AES_KEY_BITS     = 256;
    private static final int    PBKDF2_ITERS     = 310_000; // OWASP 2023 recommendation
    private static final String AES_TRANSFORM    = "AES/GCM/NoPadding";
    private static final int    GCM_TAG_BITS     = 128;

    // ------------------------------------------------------------------ //
    //  Salt & IV Generation
    // ------------------------------------------------------------------ //

    /** Generate a cryptographically secure random salt (base64-encoded) */
    public static String generateSalt() {
        byte[] salt = new byte[SALT_BYTES];
        new SecureRandom().nextBytes(salt);
        return Base64.getEncoder().encodeToString(salt);
    }

    /** Generate a random 12-byte IV for AES-GCM (base64-encoded) */
    public static String generateIV() {
        byte[] iv = new byte[IV_BYTES];
        new SecureRandom().nextBytes(iv);
        return Base64.getEncoder().encodeToString(iv);
    }

    // ------------------------------------------------------------------ //
    //  SHA-256 Hashing  (with salting to prevent rainbow tables)
    // ------------------------------------------------------------------ //

    /**
     * Computes  SHA-256(saltBytes || passwordBytes).
     * Returns lowercase hex string (64 chars).
     *
     * The salt prevents:
     *   - Rainbow table attacks  (attacker cannot precompute hashes)
     *   - Identical passwords yielding identical hashes
     */
    public static String sha256WithSalt(String password, String salt) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] saltBytes = Base64.getDecoder().decode(salt);
            digest.update(saltBytes);
            byte[] hashBytes = digest.digest(password.getBytes(StandardCharsets.UTF_8));
            return bytesToHex(hashBytes);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 unavailable", e);
        }
    }

    /**
     * Raw SHA-256 (no salt) — used for HIBP breach prefix matching.
     * First 5 hex chars → k-anonymity query to HIBP API.
     */
    public static String sha256(String input) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(input.getBytes(StandardCharsets.UTF_8));
            return bytesToHex(hash).toUpperCase();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 unavailable", e);
        }
    }

    // ------------------------------------------------------------------ //
    //  PBKDF2 Key Derivation  (master passkey → AES key)
    // ------------------------------------------------------------------ //

    /**
     * Derives a 256-bit AES key from the user's master passkey.
     * PBKDF2WithHmacSHA256 with 310,000 iterations (OWASP 2023).
     */
    public static SecretKey deriveKey(String masterPasskey, String salt) {
        try {
            byte[] saltBytes = Base64.getDecoder().decode(salt);
            SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
            KeySpec spec = new PBEKeySpec(
                    masterPasskey.toCharArray(),
                    saltBytes,
                    PBKDF2_ITERS,
                    AES_KEY_BITS
            );
            byte[] keyBytes = factory.generateSecret(spec).getEncoded();
            return new SecretKeySpec(keyBytes, "AES");
        } catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
            throw new RuntimeException("PBKDF2 key derivation failed", e);
        }
    }

    // ------------------------------------------------------------------ //
    //  AES-256-GCM Encryption / Decryption
    // ------------------------------------------------------------------ //

    /**
     * Encrypts plaintext with AES-256-GCM.
     * @param plaintext  data to encrypt
     * @param key        AES-256 key (from deriveKey)
     * @param ivBase64   base64 IV from generateIV()
     * @return base64-encoded ciphertext + GCM authentication tag
     */
    public static String encrypt(String plaintext, SecretKey key, String ivBase64) {
        try {
            byte[] iv = Base64.getDecoder().decode(ivBase64);
            Cipher cipher = Cipher.getInstance(AES_TRANSFORM);
            cipher.init(Cipher.ENCRYPT_MODE, key, new GCMParameterSpec(GCM_TAG_BITS, iv));
            byte[] cipherBytes = cipher.doFinal(plaintext.getBytes(StandardCharsets.UTF_8));
            return Base64.getEncoder().encodeToString(cipherBytes);
        } catch (GeneralSecurityException e) {
            throw new RuntimeException("Encryption failed", e);
        }
    }

    /**
     * Decrypts AES-256-GCM ciphertext.
     * GCM authentication tag is verified automatically — tampering throws AEADBadTagException.
     */
    public static String decrypt(String ciphertextBase64, SecretKey key, String ivBase64) {
        try {
            byte[] iv         = Base64.getDecoder().decode(ivBase64);
            byte[] ciphertext = Base64.getDecoder().decode(ciphertextBase64);
            Cipher cipher = Cipher.getInstance(AES_TRANSFORM);
            cipher.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(GCM_TAG_BITS, iv));
            byte[] plainBytes = cipher.doFinal(ciphertext);
            return new String(plainBytes, StandardCharsets.UTF_8);
        } catch (GeneralSecurityException e) {
            throw new RuntimeException("Decryption failed — data may be tampered", e);
        }
    }

    // ------------------------------------------------------------------ //
    //  Digital Signature (ECDSA P-256) — for phishing verification
    // ------------------------------------------------------------------ //

    /** Generate a new ECDSA P-256 key pair */
    public static KeyPair generateECKeyPair() {
        try {
            KeyPairGenerator kpg = KeyPairGenerator.getInstance("EC");
            kpg.initialize(256, new SecureRandom());
            return kpg.generateKeyPair();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("EC keygen failed", e);
        }
    }

    /** Sign data with ECDSA SHA-256 */
    public static String sign(byte[] data, PrivateKey privateKey) {
        try {
            Signature sig = Signature.getInstance("SHA256withECDSA");
            sig.initSign(privateKey);
            sig.update(data);
            return Base64.getEncoder().encodeToString(sig.sign());
        } catch (GeneralSecurityException e) {
            throw new RuntimeException("Signing failed", e);
        }
    }

    /** Verify an ECDSA SHA-256 signature */
    public static boolean verify(byte[] data, String signatureBase64, PublicKey publicKey) {
        try {
            Signature sig = Signature.getInstance("SHA256withECDSA");
            sig.initVerify(publicKey);
            sig.update(data);
            return sig.verify(Base64.getDecoder().decode(signatureBase64));
        } catch (GeneralSecurityException e) {
            return false;
        }
    }

    // ------------------------------------------------------------------ //
    //  Helpers
    // ------------------------------------------------------------------ //

    public static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) sb.append(String.format("%02x", b));
        return sb.toString();
    }

    public static boolean secureEquals(String a, String b) {
        return MessageDigest.isEqual(
                a.getBytes(StandardCharsets.UTF_8),
                b.getBytes(StandardCharsets.UTF_8));
    }
}

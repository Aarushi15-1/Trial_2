package com.vaultx.model;

/**
 * Represents a registered VaultX user.
 */
public class User {
    private int    id;
    private String username;
    private String email;
    private String passwordHash;       // BCrypt hash of master passkey
    private String salt;               // per-user salt for vault encryption
    private long   createdAt;
    private boolean emailVerified;

    public User() {}

    public User(String username, String email, String passwordHash, String salt) {
        this.username      = username;
        this.email         = email;
        this.passwordHash  = passwordHash;
        this.salt          = salt;
        this.createdAt     = System.currentTimeMillis();
        this.emailVerified = false;
    }

    // Getters & Setters
    public int     getId()            { return id; }
    public void    setId(int id)      { this.id = id; }
    public String  getUsername()      { return username; }
    public void    setUsername(String u) { this.username = u; }
    public String  getEmail()         { return email; }
    public void    setEmail(String e) { this.email = e; }
    public String  getPasswordHash()  { return passwordHash; }
    public void    setPasswordHash(String h) { this.passwordHash = h; }
    public String  getSalt()          { return salt; }
    public void    setSalt(String s)  { this.salt = s; }
    public long    getCreatedAt()     { return createdAt; }
    public void    setCreatedAt(long t) { this.createdAt = t; }
    public boolean isEmailVerified()  { return emailVerified; }
    public void    setEmailVerified(boolean v) { this.emailVerified = v; }

    @Override
    public String toString() {
        return "User{id=" + id + ", username='" + username + "', email='" + email + "'}";
    }
}

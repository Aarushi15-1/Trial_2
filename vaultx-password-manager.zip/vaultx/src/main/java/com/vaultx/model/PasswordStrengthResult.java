package com.vaultx.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Detailed result from PasswordAnalyser.
 */
public class PasswordStrengthResult {
    private int    score;          // 0-100
    private String grade;          // "Very Weak" | "Weak" | "Fair" | "Strong" | "Very Strong"
    private boolean breached;
    private List<String> suggestions = new ArrayList<>();
    private List<String> warnings    = new ArrayList<>();

    // Individual sub-scores (0-20 each, total 100)
    private int lengthScore;
    private int complexityScore;
    private int patternScore;
    private int dictionaryScore;
    private int entropyScore;

    public PasswordStrengthResult() {}

    public void computeGrade() {
        if      (score >= 80) grade = "Very Strong";
        else if (score >= 60) grade = "Strong";
        else if (score >= 40) grade = "Fair";
        else if (score >= 20) grade = "Weak";
        else                  grade = "Very Weak";
    }

    public void addSuggestion(String s) { suggestions.add(s); }
    public void addWarning(String w)    { warnings.add(w); }

    // Getters & Setters
    public int    getScore()           { return score; }
    public void   setScore(int s)      { this.score = s; }
    public String getGrade()           { return grade; }
    public void   setGrade(String g)   { this.grade = g; }
    public boolean isBreached()        { return breached; }
    public void    setBreached(boolean b) { this.breached = b; }
    public List<String> getSuggestions(){ return suggestions; }
    public List<String> getWarnings()  { return warnings; }
    public int getLengthScore()        { return lengthScore; }
    public void setLengthScore(int l)  { this.lengthScore = l; }
    public int getComplexityScore()    { return complexityScore; }
    public void setComplexityScore(int c) { this.complexityScore = c; }
    public int getPatternScore()       { return patternScore; }
    public void setPatternScore(int p) { this.patternScore = p; }
    public int getDictionaryScore()    { return dictionaryScore; }
    public void setDictionaryScore(int d) { this.dictionaryScore = d; }
    public int getEntropyScore()       { return entropyScore; }
    public void setEntropyScore(int e) { this.entropyScore = e; }
}

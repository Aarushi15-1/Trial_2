package com.vaultx.servlet;

import com.google.gson.Gson;
import com.vaultx.model.PasswordStrengthResult;
import com.vaultx.service.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.util.*;

/**
 * Security Tools API
 *
 *   POST /api/tools/analyse       → analyse password strength
 *   POST /api/tools/generate      → generate random password
 *   POST /api/tools/phishing      → check URL for phishing
 *   GET  /api/tools/login-history → fetch login events for current user
 */
@WebServlet("/api/tools/*")
public class ToolsServlet extends HttpServlet {

    private static final Gson GSON = new Gson();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("application/json;charset=UTF-8");
        String path = req.getPathInfo();

        switch (path == null ? "" : path) {
            case "/analyse"  -> handleAnalyse(req, resp);
            case "/generate" -> handleGenerate(req, resp);
            case "/phishing" -> handlePhishing(req, resp);
            default          -> resp.sendError(404, "Unknown tool endpoint");
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("application/json;charset=UTF-8");
        if ("/login-history".equals(req.getPathInfo())) handleLoginHistory(req, resp);
        else resp.sendError(404);
    }

    // ------------------------------------------------------------------ //
    //  Password Strength Analyser
    // ------------------------------------------------------------------ //

    private void handleAnalyse(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Map<String, Object> body = parseBody(req);
        String password = (String) body.get("password");

        if (isBlank(password)) { sendError(resp, 400, "password is required"); return; }

        PasswordStrengthResult result = PasswordAnalyser.analyse(password);

        // If weak, generate suggestions
        List<String> suggestions = new ArrayList<>();
        if (result.getScore() < 60) {
            suggestions = PasswordGenerator.suggest(Math.max(password.length(), 16), 3);
        }

        Map<String, Object> response = new LinkedHashMap<>();
        response.put("score",          result.getScore());
        response.put("grade",          result.getGrade());
        response.put("breached",       result.isBreached());
        response.put("lengthScore",    result.getLengthScore());
        response.put("complexityScore",result.getComplexityScore());
        response.put("patternScore",   result.getPatternScore());
        response.put("dictionaryScore",result.getDictionaryScore());
        response.put("entropyScore",   result.getEntropyScore());
        response.put("warnings",       result.getWarnings());
        response.put("suggestions_text", result.getSuggestions());
        response.put("suggested_passwords", suggestions);

        sendSuccess(resp, 200, response);
    }

    // ------------------------------------------------------------------ //
    //  Password Generator
    // ------------------------------------------------------------------ //

    private void handleGenerate(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Map<String, Object> body = parseBody(req);

        int length = body.containsKey("length")
                ? ((Number) body.get("length")).intValue() : 20;
        boolean useSymbols  = !Boolean.FALSE.equals(body.get("useSymbols"));
        boolean useDigits   = !Boolean.FALSE.equals(body.get("useDigits"));
        boolean useUpper    = !Boolean.FALSE.equals(body.get("useUpper"));
        boolean useLower    = !Boolean.FALSE.equals(body.get("useLower"));
        boolean passphrase  = Boolean.TRUE.equals(body.get("passphrase"));

        String generated;
        if (passphrase) {
            generated = PasswordGenerator.generatePassphrase(4);
        } else {
            generated = PasswordGenerator.generate(length, useLower, useUpper, useDigits, useSymbols, false);
        }

        PasswordStrengthResult strength = PasswordAnalyser.analyse(generated);

        sendSuccess(resp, 200, Map.of(
                "password",      generated,
                "score",         strength.getScore(),
                "grade",         strength.getGrade(),
                "length",        generated.length()
        ));
    }

    // ------------------------------------------------------------------ //
    //  Phishing Detector
    // ------------------------------------------------------------------ //

    private void handlePhishing(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Map<String, Object> body = parseBody(req);
        String url = (String) body.get("url");

        if (isBlank(url)) { sendError(resp, 400, "url is required"); return; }

        PhishingDetector.PhishingResult result = PhishingDetector.analyzeUrl(url);

        sendSuccess(resp, 200, Map.of(
                "url",          url,
                "isPhishing",   result.isPhishing,
                "threatLevel",  result.threatLevel,
                "threatLabel",  result.getThreatLabel(),
                "riskType",     result.riskType,
                "message",      result.message
        ));
    }

    // ------------------------------------------------------------------ //
    //  Login History
    // ------------------------------------------------------------------ //

    private void handleLoginHistory(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        int userId = resolveUserId(req, resp);
        if (userId == -1) return;

        try {
            java.sql.ResultSet rs = com.vaultx.util.DatabaseManager.getLoginEvents(userId, 50);
            List<Map<String, Object>> events = new ArrayList<>();
            while (rs.next()) {
                Map<String, Object> e = new LinkedHashMap<>();
                e.put("id",         rs.getInt("id"));
                e.put("timestamp",  rs.getLong("timestamp"));
                e.put("ipAddress",  rs.getString("ip_address"));
                e.put("location",   rs.getString("location"));
                e.put("successful", rs.getInt("successful") == 1);
                e.put("riskScore",  rs.getDouble("risk_score"));
                e.put("riskReason", rs.getString("risk_reason"));
                e.put("alertSent",  rs.getInt("alert_sent") == 1);
                events.add(e);
            }
            sendSuccess(resp, 200, Map.of("events", events));
        } catch (Exception e) {
            sendError(resp, 500, "Failed to fetch login history");
        }
    }

    // ------------------------------------------------------------------ //
    //  Helpers
    // ------------------------------------------------------------------ //

    private int resolveUserId(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String token = null;
        if (req.getCookies() != null) {
            for (Cookie c : req.getCookies()) {
                if ("vaultx_session".equals(c.getName())) { token = c.getValue(); break; }
            }
        }
        if (token == null) { sendError(resp, 401, "Not authenticated"); return -1; }
        try {
            java.sql.ResultSet session = com.vaultx.util.DatabaseManager.findSession(token);
            if (!session.next()) { sendError(resp, 401, "Session expired"); return -1; }
            return session.getInt("user_id");
        } catch (Exception e) { sendError(resp, 500, "Session error"); return -1; }
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> parseBody(HttpServletRequest req) throws IOException {
        return GSON.fromJson(req.getReader(), Map.class);
    }

    private boolean isBlank(String s) { return s == null || s.isBlank(); }

    private void sendSuccess(HttpServletResponse resp, int status, Object data) throws IOException {
        resp.setStatus(status);
        resp.getWriter().write(GSON.toJson(data));
    }

    private void sendError(HttpServletResponse resp, int status, String msg) throws IOException {
        resp.setStatus(status);
        resp.getWriter().write(GSON.toJson(Map.of("error", msg)));
    }
}

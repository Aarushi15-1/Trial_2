package com.vaultx.util;

import java.sql.*;

/**
 * SQLite database manager.
 * Creates all tables on first run and provides connection pooling.
 */
public class DatabaseManager {

    private static final String DB_URL = "jdbc:sqlite:vaultx.db";
    private static Connection sharedConn;

    public static synchronized Connection getConnection() throws SQLException {
        if (sharedConn == null || sharedConn.isClosed()) {
            sharedConn = DriverManager.getConnection(DB_URL);
            sharedConn.setAutoCommit(true);
            initSchema(sharedConn);
        }
        return sharedConn;
    }

    private static void initSchema(Connection conn) throws SQLException {
        try (Statement s = conn.createStatement()) {
            // Users table
            s.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    id           INTEGER PRIMARY KEY AUTOINCREMENT,
                    username     TEXT    NOT NULL UNIQUE,
                    email        TEXT    NOT NULL UNIQUE,
                    password_hash TEXT   NOT NULL,
                    salt         TEXT    NOT NULL,
                    created_at   INTEGER NOT NULL,
                    email_verified INTEGER DEFAULT 0
                )""");

            // Password entries table
            s.execute("""
                CREATE TABLE IF NOT EXISTS password_entries (
                    id                 INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id            INTEGER NOT NULL,
                    site_url           TEXT,
                    site_name          TEXT,
                    site_username      TEXT,
                    encrypted_password TEXT    NOT NULL,
                    iv                 TEXT    NOT NULL,
                    password_hash      TEXT    NOT NULL,
                    strength_score     INTEGER DEFAULT 0,
                    category           TEXT    DEFAULT 'General',
                    notes              TEXT,
                    created_at         INTEGER NOT NULL,
                    updated_at         INTEGER NOT NULL,
                    FOREIGN KEY (user_id) REFERENCES users(id)
                )""");

            // Login events table
            s.execute("""
                CREATE TABLE IF NOT EXISTS login_events (
                    id          INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id     INTEGER NOT NULL,
                    timestamp   INTEGER NOT NULL,
                    ip_address  TEXT,
                    location    TEXT,
                    successful  INTEGER DEFAULT 1,
                    risk_score  REAL    DEFAULT 0.0,
                    risk_reason TEXT,
                    alert_sent  INTEGER DEFAULT 0,
                    FOREIGN KEY (user_id) REFERENCES users(id)
                )""");

            // Sessions table
            s.execute("""
                CREATE TABLE IF NOT EXISTS sessions (
                    session_token TEXT    PRIMARY KEY,
                    user_id       INTEGER NOT NULL,
                    created_at    INTEGER NOT NULL,
                    expires_at    INTEGER NOT NULL,
                    ip_address    TEXT,
                    FOREIGN KEY (user_id) REFERENCES users(id)
                )""");

            System.out.println("[DB] Schema initialised successfully.");
        }
    }

    // ------------------------------------------------------------------ //
    //  User CRUD
    // ------------------------------------------------------------------ //

    public static int insertUser(String username, String email, String passwordHash, String salt)
            throws SQLException {
        String sql = "INSERT INTO users (username, email, password_hash, salt, created_at) VALUES (?,?,?,?,?)";
        try (PreparedStatement ps = getConnection().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, username);
            ps.setString(2, email);
            ps.setString(3, passwordHash);
            ps.setString(4, salt);
            ps.setLong(5, System.currentTimeMillis());
            ps.executeUpdate();
            ResultSet rs = ps.getGeneratedKeys();
            return rs.next() ? rs.getInt(1) : -1;
        }
    }

    public static ResultSet findUserByUsername(String username) throws SQLException {
        PreparedStatement ps = getConnection()
                .prepareStatement("SELECT * FROM users WHERE username = ?");
        ps.setString(1, username);
        return ps.executeQuery();
    }

    public static ResultSet findUserByEmail(String email) throws SQLException {
        PreparedStatement ps = getConnection()
                .prepareStatement("SELECT * FROM users WHERE email = ?");
        ps.setString(1, email);
        return ps.executeQuery();
    }

    // ------------------------------------------------------------------ //
    //  Password Entry CRUD
    // ------------------------------------------------------------------ //

    public static int insertPasswordEntry(int userId, String siteUrl, String siteName,
                                           String siteUsername, String encryptedPassword,
                                           String iv, String passwordHash, int strengthScore,
                                           String category, String notes) throws SQLException {
        String sql = """
            INSERT INTO password_entries
            (user_id, site_url, site_name, site_username, encrypted_password, iv,
             password_hash, strength_score, category, notes, created_at, updated_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""";
        try (PreparedStatement ps = getConnection().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            long now = System.currentTimeMillis();
            ps.setInt(1, userId);    ps.setString(2, siteUrl);  ps.setString(3, siteName);
            ps.setString(4, siteUsername); ps.setString(5, encryptedPassword); ps.setString(6, iv);
            ps.setString(7, passwordHash); ps.setInt(8, strengthScore);
            ps.setString(9, category);  ps.setString(10, notes);
            ps.setLong(11, now); ps.setLong(12, now);
            ps.executeUpdate();
            ResultSet rs = ps.getGeneratedKeys();
            return rs.next() ? rs.getInt(1) : -1;
        }
    }

    public static ResultSet getPasswordEntries(int userId) throws SQLException {
        PreparedStatement ps = getConnection()
                .prepareStatement("SELECT * FROM password_entries WHERE user_id = ? ORDER BY site_name");
        ps.setInt(1, userId);
        return ps.executeQuery();
    }

    public static boolean deletePasswordEntry(int entryId, int userId) throws SQLException {
        PreparedStatement ps = getConnection()
                .prepareStatement("DELETE FROM password_entries WHERE id = ? AND user_id = ?");
        ps.setInt(1, entryId); ps.setInt(2, userId);
        return ps.executeUpdate() > 0;
    }

    // ------------------------------------------------------------------ //
    //  Login Events CRUD
    // ------------------------------------------------------------------ //

    public static void insertLoginEvent(int userId, long timestamp, String ip, String location,
                                         boolean successful, double riskScore, String riskReason,
                                         boolean alertSent) throws SQLException {
        String sql = """
            INSERT INTO login_events
            (user_id, timestamp, ip_address, location, successful, risk_score, risk_reason, alert_sent)
            VALUES (?,?,?,?,?,?,?,?)""";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setInt(1, userId); ps.setLong(2, timestamp); ps.setString(3, ip);
            ps.setString(4, location); ps.setInt(5, successful ? 1 : 0);
            ps.setDouble(6, riskScore); ps.setString(7, riskReason);
            ps.setInt(8, alertSent ? 1 : 0);
            ps.executeUpdate();
        }
    }

    public static ResultSet getLoginEvents(int userId, int limit) throws SQLException {
        PreparedStatement ps = getConnection().prepareStatement(
                "SELECT * FROM login_events WHERE user_id = ? ORDER BY timestamp DESC LIMIT ?");
        ps.setInt(1, userId); ps.setInt(2, limit);
        return ps.executeQuery();
    }

    // ------------------------------------------------------------------ //
    //  Sessions CRUD
    // ------------------------------------------------------------------ //

    public static void insertSession(String token, int userId, String ip) throws SQLException {
        String sql = "INSERT INTO sessions (session_token, user_id, created_at, expires_at, ip_address) VALUES (?,?,?,?,?)";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            long now = System.currentTimeMillis();
            ps.setString(1, token); ps.setInt(2, userId);
            ps.setLong(3, now); ps.setLong(4, now + 8 * 3600 * 1000L);
            ps.setString(5, ip);
            ps.executeUpdate();
        }
    }

    public static ResultSet findSession(String token) throws SQLException {
        PreparedStatement ps = getConnection()
                .prepareStatement("SELECT * FROM sessions WHERE session_token = ? AND expires_at > ?");
        ps.setString(1, token); ps.setLong(2, System.currentTimeMillis());
        return ps.executeQuery();
    }

    public static void deleteSession(String token) throws SQLException {
        PreparedStatement ps = getConnection()
                .prepareStatement("DELETE FROM sessions WHERE session_token = ?");
        ps.setString(1, token);
        ps.executeUpdate();
    }
}

package com.vaultx;

import com.vaultx.crypto.CryptoUtil;
import com.vaultx.dsa.*;
import com.vaultx.model.LoginEvent;
import com.vaultx.model.PasswordStrengthResult;
import com.vaultx.service.PasswordAnalyser;
import com.vaultx.service.PasswordGenerator;
import com.vaultx.service.PhishingDetector;
import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

public class VaultXTests {

    // ─── BloomFilter ──────────────────────────────────────────────────────── //

    @Test
    void bloomFilter_noFalseNegatives() {
        BloomFilter bf = new BloomFilter(100_000, 7);
        String[] items = {"password123", "letmein", "dragon", "abc123"};
        for (String s : items) bf.add(s);
        for (String s : items) assertTrue(bf.mightContain(s), "False negative for: " + s);
    }

    @Test
    void bloomFilter_falsePositiveRateAcceptable() {
        BloomFilter bf = new BloomFilter();
        for (int i = 0; i < 1000; i++) bf.add("item-" + i);
        int fps = 0;
        for (int i = 1000; i < 2000; i++) if (bf.mightContain("item-" + i)) fps++;
        double fpRate = (double)fps / 1000;
        System.out.printf("BloomFilter FP rate: %.4f%%%n", fpRate * 100);
        assertTrue(fpRate < 0.05, "FP rate too high: " + fpRate);
    }

    // ─── AVLTree ──────────────────────────────────────────────────────────── //

    @Test
    void avlTree_insertAndSearch() {
        AVLTree tree = new AVLTree();
        for (int i = 0; i < 20; i++) {
            LoginEvent e = new LoginEvent(1, 1000L * (i+1), "127.0.0.1", "Local", true);
            tree.insert(e);
        }
        assertEquals(20, tree.size());
    }

    @Test
    void avlTree_inorderIsSorted() {
        AVLTree tree = new AVLTree();
        long[] times = {5000L, 1000L, 8000L, 3000L, 7000L};
        for (long t : times) tree.insert(new LoginEvent(1, t, "ip", "loc", true));

        List<LoginEvent> sorted = tree.inorderList();
        for (int i = 1; i < sorted.size(); i++) {
            assertTrue(sorted.get(i).getTimestamp() >= sorted.get(i-1).getTimestamp(),
                    "AVL inorder not sorted at index " + i);
        }
    }

    @Test
    void avlTree_rangeQuery() {
        AVLTree tree = new AVLTree();
        for (long t = 1000L; t <= 10000L; t += 1000L) {
            tree.insert(new LoginEvent(1, t, "ip", "loc", true));
        }
        List<LoginEvent> range = tree.rangeQuery(3000L, 6000L);
        assertEquals(4, range.size(), "Expected events at 3000,4000,5000,6000");
    }

    // ─── MinHeap ──────────────────────────────────────────────────────────── //

    @Test
    void minHeap_extractsInRiskOrder() {
        MinHeap heap = new MinHeap();
        double[] risks = {0.9, 0.1, 0.7, 0.3, 0.5};
        for (double r : risks) {
            LoginEvent e = new LoginEvent(1, 0, "ip", "loc", true);
            e.setRiskScore(r);
            heap.insert(e);
        }
        double prev = -1;
        while (!heap.isEmpty()) {
            LoginEvent e = heap.extractMin();
            assertTrue(e.getRiskScore() >= prev);
            prev = e.getRiskScore();
        }
    }

    // ─── HashTable ────────────────────────────────────────────────────────── //

    @Test
    void hashTable_putGetDelete() {
        HashTable<String, String> ht = new HashTable<>();
        ht.put("u1:github.com", "encrypted-pw-1");
        ht.put("u1:gmail.com",  "encrypted-pw-2");
        ht.put("u2:github.com", "encrypted-pw-3");

        assertEquals("encrypted-pw-1", ht.get("u1:github.com"));
        assertEquals(3, ht.size());

        ht.delete("u1:github.com");
        assertNull(ht.get("u1:github.com"));
        assertEquals(2, ht.size());
    }

    @Test
    void hashTable_prefixSearch() {
        HashTable<String, String> ht = new HashTable<>();
        ht.put("u5:site1", "val1");
        ht.put("u5:site2", "val2");
        ht.put("u9:site1", "val3");

        List<String> u5 = ht.getByKeyPrefix("u5:");
        assertEquals(2, u5.size());
    }

    // ─── Trie ─────────────────────────────────────────────────────────────── //

    @Test
    void trie_exactMatchDetected() {
        Trie trie = new Trie();
        trie.insert("paypa1.com", 2);
        assertTrue(trie.containsDomain("paypa1.com"));
        assertFalse(trie.containsDomain("paypal.com"));
    }

    @Test
    void trie_phishingHeuristicsDetectIp() {
        Trie trie = new Trie();
        Trie.PhishResult r = trie.analyzeUrl("http://192.168.1.100/login");
        assertTrue(r.isPhishing, "IP-based URL should be flagged");
    }

    @Test
    void trie_brandSpoofingDetected() {
        Trie trie = new Trie();
        Trie.PhishResult r = trie.analyzeUrl("http://secure-paypal-login.xyz/account");
        assertTrue(r.isPhishing, "Brand spoof URL should be flagged");
    }

    // ─── CryptoUtil ───────────────────────────────────────────────────────── //

    @Test
    void sha256WithSalt_differentSaltsDifferentHashes() {
        String pw    = "MyPassword123!";
        String salt1 = CryptoUtil.generateSalt();
        String salt2 = CryptoUtil.generateSalt();
        String hash1 = CryptoUtil.sha256WithSalt(pw, salt1);
        String hash2 = CryptoUtil.sha256WithSalt(pw, salt2);
        assertNotEquals(hash1, hash2, "Different salts must yield different hashes");
    }

    @Test
    void sha256WithSalt_sameSaltSameHash() {
        String pw   = "MyPassword123!";
        String salt = CryptoUtil.generateSalt();
        assertEquals(CryptoUtil.sha256WithSalt(pw, salt), CryptoUtil.sha256WithSalt(pw, salt));
    }

    @Test
    void aesGcm_encryptDecryptRoundtrip() {
        String plaintext = "super-secret-password-42";
        String salt      = CryptoUtil.generateSalt();
        String iv        = CryptoUtil.generateIV();
        javax.crypto.SecretKey key = CryptoUtil.deriveKey("MasterPasskey!", salt);

        String encrypted = CryptoUtil.encrypt(plaintext, key, iv);
        String decrypted = CryptoUtil.decrypt(encrypted, key, iv);

        assertEquals(plaintext, decrypted);
    }

    @Test
    void aesGcm_wrongKeyFails() {
        String salt = CryptoUtil.generateSalt();
        String iv   = CryptoUtil.generateIV();
        javax.crypto.SecretKey key1 = CryptoUtil.deriveKey("RightKey!", salt);
        javax.crypto.SecretKey key2 = CryptoUtil.deriveKey("WrongKey!", salt);

        String enc = CryptoUtil.encrypt("secret", key1, iv);
        assertThrows(RuntimeException.class, () -> CryptoUtil.decrypt(enc, key2, iv));
    }

    @Test
    void ecdsaSignatureVerifies() {
        java.security.KeyPair kp = CryptoUtil.generateECKeyPair();
        byte[] data = "vaultx.example.com".getBytes();
        String sig  = CryptoUtil.sign(data, kp.getPrivate());
        assertTrue(CryptoUtil.verify(data, sig, kp.getPublic()));
        assertFalse(CryptoUtil.verify("tampered.com".getBytes(), sig, kp.getPublic()));
    }

    // ─── PasswordAnalyser ─────────────────────────────────────────────────── //

    @Test
    void analyser_weakPassword() {
        PasswordStrengthResult r = PasswordAnalyser.analyse("password");
        assertTrue(r.getScore() < 40, "Common 'password' should score < 40, got " + r.getScore());
        assertTrue(r.isBreached(), "'password' should be flagged as breached");
    }

    @Test
    void analyser_strongPassword() {
        PasswordStrengthResult r = PasswordAnalyser.analyse("X7#mK!vQpN2@wR9$");
        assertTrue(r.getScore() >= 60, "Strong password should score >= 60, got " + r.getScore());
    }

    @Test
    void analyser_emptyPassword() {
        PasswordStrengthResult r = PasswordAnalyser.analyse("");
        assertEquals(0, r.getScore());
    }

    // ─── PasswordGenerator ────────────────────────────────────────────────── //

    @Test
    void generator_correctLength() {
        for (int len : new int[]{8, 16, 32, 64}) {
            String pw = PasswordGenerator.generate(len);
            assertEquals(len, pw.length(), "Generated length mismatch for target " + len);
        }
    }

    @Test
    void generator_strongOutput() {
        for (int i = 0; i < 10; i++) {
            String pw = PasswordGenerator.generate(20);
            PasswordStrengthResult r = PasswordAnalyser.analyse(pw);
            assertTrue(r.getScore() >= 60,
                    "Generated password too weak (score=" + r.getScore() + "): " + pw);
        }
    }

    @Test
    void generator_passphraseNotBlank() {
        String pp = PasswordGenerator.generatePassphrase(4);
        assertFalse(pp.isBlank());
        assertTrue(pp.contains("-"), "Passphrase should contain hyphens");
    }

    // ─── PhishingDetector ─────────────────────────────────────────────────── //

    @Test
    void phishingDetector_safeUrl() {
        PhishingDetector.PhishingResult r = PhishingDetector.analyzeUrl("https://github.com");
        assertFalse(r.isPhishing);
    }

    @Test
    void phishingDetector_blockedDomain() {
        PhishingDetector.PhishingResult r = PhishingDetector.analyzeUrl("http://paypa1.com/login");
        assertTrue(r.isPhishing);
        assertTrue(r.threatLevel >= 2);
    }

    @Test
    void phishingDetector_digitalSignatureVerification() {
        String domain = "mytrusteddomain.com";
        String sig    = PhishingDetector.registerTrustedSite(domain);
        assertTrue(PhishingDetector.verifyDomainSignature(domain, sig));
        assertFalse(PhishingDetector.verifyDomainSignature("otherdomain.com", sig));
    }
}

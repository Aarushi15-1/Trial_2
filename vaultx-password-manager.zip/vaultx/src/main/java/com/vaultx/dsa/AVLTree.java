package com.vaultx.dsa;

import com.vaultx.model.LoginEvent;
import java.util.ArrayList;
import java.util.List;

/**
 * ============================================================
 * AVL TREE — Self-Balancing Binary Search Tree
 * ============================================================
 * Stores LoginEvent objects sorted by timestamp (epoch ms).
 *
 * Operations:
 *   insert   → O(log n)
 *   search   → O(log n)
 *   rangeQuery (start..end timestamps) → O(log n + k)
 *   inorder traversal → O(n)
 *
 * Used by LoginTracker to efficiently:
 *   - Store login history per user
 *   - Query logins in a time range (e.g. last 24 h)
 *   - Detect anomalous login hours via range queries
 * ============================================================
 */
public class AVLTree {

    // ------------------------------------------------------------------ //
    //  Node
    // ------------------------------------------------------------------ //
    private static class Node {
        LoginEvent data;
        long       key;        // timestamp in epoch millis
        Node       left, right;
        int        height;

        Node(LoginEvent event) {
            this.data   = event;
            this.key    = event.getTimestamp();
            this.height = 1;
        }
    }

    private Node root;
    private int  size;

    // ------------------------------------------------------------------ //
    //  Public API
    // ------------------------------------------------------------------ //

    public void insert(LoginEvent event) {
        root = insertRec(root, event);
        size++;
    }

    public LoginEvent search(long timestamp) {
        Node node = searchRec(root, timestamp);
        return node == null ? null : node.data;
    }

    /** Returns all login events with timestamp in [startMs, endMs]. */
    public List<LoginEvent> rangeQuery(long startMs, long endMs) {
        List<LoginEvent> result = new ArrayList<>();
        rangeQueryRec(root, startMs, endMs, result);
        return result;
    }

    /** In-order traversal → chronologically sorted list */
    public List<LoginEvent> inorderList() {
        List<LoginEvent> result = new ArrayList<>();
        inorderRec(root, result);
        return result;
    }

    public int size()    { return size; }
    public boolean isEmpty() { return root == null; }

    // ------------------------------------------------------------------ //
    //  Internal: insert + rebalance
    // ------------------------------------------------------------------ //

    private Node insertRec(Node node, LoginEvent event) {
        if (node == null) return new Node(event);

        long key = event.getTimestamp();

        if (key < node.key) {
            node.left  = insertRec(node.left, event);
        } else if (key > node.key) {
            node.right = insertRec(node.right, event);
        } else {
            // Duplicate timestamp: append with +1 to keep all records
            node.right = insertRec(node.right,
                    new LoginEvent(event.getUserId(), event.getTimestamp() + 1,
                            event.getIpAddress(), event.getLocation(), event.isSuccessful()));
        }

        updateHeight(node);
        return balance(node);
    }

    private Node balance(Node node) {
        int bf = balanceFactor(node);

        // Left-Left
        if (bf > 1 && balanceFactor(node.left) >= 0)
            return rotateRight(node);

        // Left-Right
        if (bf > 1 && balanceFactor(node.left) < 0) {
            node.left = rotateLeft(node.left);
            return rotateRight(node);
        }

        // Right-Right
        if (bf < -1 && balanceFactor(node.right) <= 0)
            return rotateLeft(node);

        // Right-Left
        if (bf < -1 && balanceFactor(node.right) > 0) {
            node.right = rotateRight(node.right);
            return rotateLeft(node);
        }

        return node;
    }

    private Node rotateRight(Node y) {
        Node x  = y.left;
        Node T2 = x.right;
        x.right = y;
        y.left  = T2;
        updateHeight(y);
        updateHeight(x);
        return x;
    }

    private Node rotateLeft(Node x) {
        Node y  = x.right;
        Node T2 = y.left;
        y.left  = x;
        x.right = T2;
        updateHeight(x);
        updateHeight(y);
        return y;
    }

    // ------------------------------------------------------------------ //
    //  Internal: search + range
    // ------------------------------------------------------------------ //

    private Node searchRec(Node node, long key) {
        if (node == null || node.key == key) return node;
        return key < node.key ? searchRec(node.left, key) : searchRec(node.right, key);
    }

    private void rangeQueryRec(Node node, long lo, long hi, List<LoginEvent> result) {
        if (node == null) return;
        if (lo < node.key) rangeQueryRec(node.left,  lo, hi, result);
        if (lo <= node.key && node.key <= hi) result.add(node.data);
        if (hi > node.key) rangeQueryRec(node.right, lo, hi, result);
    }

    private void inorderRec(Node node, List<LoginEvent> result) {
        if (node == null) return;
        inorderRec(node.left, result);
        result.add(node.data);
        inorderRec(node.right, result);
    }

    // ------------------------------------------------------------------ //
    //  Helpers
    // ------------------------------------------------------------------ //

    private int height(Node n)        { return n == null ? 0 : n.height; }
    private int balanceFactor(Node n) { return n == null ? 0 : height(n.left) - height(n.right); }
    private void updateHeight(Node n) { n.height = 1 + Math.max(height(n.left), height(n.right)); }
}

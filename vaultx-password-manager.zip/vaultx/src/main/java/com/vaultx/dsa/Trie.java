package com.vaultx.dsa;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * ============================================================
 * TRIE (Prefix Tree) — Phishing URL Detection
 * ============================================================
 * Stores known phishing / malicious domains character by character.
 *
 * Operations:
 *   insert(domain)          → O(L)  where L = domain length
 *   searchExact(domain)     → O(L)
 *   searchPrefix(prefix)    → O(L + k) returns all matches
 *   containsSuspicious(url) → O(L)
 *
 * Also used for auto-suggest / typo-squatting detection:
 *   "paypa1.com" → prefix "paypa" matches known "paypal.com"
 *
 * The Trie is populated at startup from phishing_domains.txt
 * (bundled in resources) and augmented via the PhishingService.
 * ============================================================
 */
public class Trie {

    // ------------------------------------------------------------------ //
    //  TrieNode
    // ------------------------------------------------------------------ //
    private static class TrieNode {
        Map<Character, TrieNode> children = new HashMap<>();
        boolean isEndOfWord  = false;
        String  fullDomain   = null;    // stored at terminal node
        int     threatLevel  = 0;       // 1=suspicious 2=confirmed phish 3=malware
    }

    private final TrieNode root;
    private int     wordCount;

    public Trie() {
        this.root      = new TrieNode();
        this.wordCount = 0;
    }

    // ------------------------------------------------------------------ //
    //  Insert
    // ------------------------------------------------------------------ //

    public void insert(String domain) {
        insert(domain, 2);
    }

    public void insert(String domain, int threatLevel) {
        if (domain == null || domain.isEmpty()) return;
        String norm = normalize(domain);

        TrieNode current = root;
        for (char ch : norm.toCharArray()) {
            current.children.putIfAbsent(ch, new TrieNode());
            current = current.children.get(ch);
        }
        if (!current.isEndOfWord) wordCount++;
        current.isEndOfWord = true;
        current.fullDomain  = norm;
        current.threatLevel = Math.max(current.threatLevel, threatLevel);
    }

    // ------------------------------------------------------------------ //
    //  Search
    // ------------------------------------------------------------------ //

    /** Exact match — returns threat level 0 if not found */
    public int searchThreatLevel(String domain) {
        TrieNode node = getNode(normalize(domain));
        return (node != null && node.isEndOfWord) ? node.threatLevel : 0;
    }

    public boolean containsDomain(String domain) {
        return searchThreatLevel(domain) > 0;
    }

    /**
     * Prefix search — for typosquatting detection.
     * Returns all stored domains that start with the given prefix.
     */
    public List<String> prefixSearch(String prefix) {
        List<String> results = new ArrayList<>();
        TrieNode node = getNode(normalize(prefix));
        if (node == null) return results;
        collectWords(node, results);
        return results;
    }

    /**
     * Checks a full URL for phishing indicators:
     *  1. Exact domain match
     *  2. Prefix match suggesting typosquatting
     *  3. Contains deceptive substrings (e.g. "secure-paypal")
     */
    public PhishResult analyzeUrl(String rawUrl) {
        String domain  = extractDomain(rawUrl);
        int    exact   = searchThreatLevel(domain);
        if (exact > 0) return new PhishResult(true, exact, "Domain in phishing blocklist: " + domain);

        // Typosquatting: check if domain is within edit-distance 1 of a known phishing domain
        // (simplified: prefix check on first 6 chars)
        if (domain.length() >= 6) {
            String prefix = domain.substring(0, 6);
            List<String> candidates = prefixSearch(prefix);
            for (String candidate : candidates) {
                if (levenshtein(domain, candidate) <= 2) {
                    return new PhishResult(true, 1,
                            "Possible typosquat of known phishing domain: " + candidate);
                }
            }
        }

        // Heuristic checks
        String reason = heuristicCheck(rawUrl, domain);
        if (reason != null) return new PhishResult(true, 1, reason);

        return new PhishResult(false, 0, "URL appears safe");
    }

    // ------------------------------------------------------------------ //
    //  Heuristics
    // ------------------------------------------------------------------ //

    private String heuristicCheck(String url, String domain) {
        // IP address as hostname
        if (domain.matches("\\d{1,3}(\\.\\d{1,3}){3}"))
            return "IP address used as URL hostname (suspicious)";

        // Excessive subdomains
        long dots = domain.chars().filter(c -> c == '.').count();
        if (dots > 4) return "Excessive subdomain depth (" + dots + " dots)";

        // Known brand names in suspicious positions
        String[] brands = {"paypal","google","microsoft","apple","amazon","facebook","netflix","bankofamerica"};
        String urlLower = url.toLowerCase();
        for (String brand : brands) {
            if (urlLower.contains(brand) && !domain.endsWith(brand + ".com")
                    && !domain.endsWith(brand + ".net")) {
                return "Brand name '" + brand + "' in URL but not official domain";
            }
        }

        // Suspicious keywords
        String[] keywords = {"login","signin","secure","verify","account","update","confirm","bank"};
        int kwCount = 0;
        for (String kw : keywords) if (urlLower.contains(kw)) kwCount++;
        if (kwCount >= 3) return "URL contains multiple phishing keywords (" + kwCount + ")";

        // Long URLs
        if (url.length() > 200) return "Unusually long URL (" + url.length() + " chars)";

        // URL encoded characters
        long encodedCount = 0;
        for (int i = 0; i < url.length() - 2; i++)
            if (url.charAt(i) == '%') encodedCount++;
        if (encodedCount > 4) return "Excessive URL encoding (obfuscation attempt)";

        return null;
    }

    // ------------------------------------------------------------------ //
    //  Helpers
    // ------------------------------------------------------------------ //

    private TrieNode getNode(String word) {
        TrieNode current = root;
        for (char ch : word.toCharArray()) {
            if (!current.children.containsKey(ch)) return null;
            current = current.children.get(ch);
        }
        return current;
    }

    private void collectWords(TrieNode node, List<String> result) {
        if (node.isEndOfWord && node.fullDomain != null) result.add(node.fullDomain);
        for (TrieNode child : node.children.values()) collectWords(child, result);
    }

    private String normalize(String s) { return s.toLowerCase().trim(); }

    public static String extractDomain(String url) {
        String d = url.toLowerCase()
                .replaceAll("https?://", "")
                .replaceAll("www\\.", "")
                .split("[/?#]")[0];
        return d;
    }

    /** Classic dynamic-programming Levenshtein distance */
    private int levenshtein(String a, String b) {
        int m = a.length(), n = b.length();
        int[][] dp = new int[m + 1][n + 1];
        for (int i = 0; i <= m; i++) dp[i][0] = i;
        for (int j = 0; j <= n; j++) dp[0][j] = j;
        for (int i = 1; i <= m; i++)
            for (int j = 1; j <= n; j++) {
                int cost = a.charAt(i-1) == b.charAt(j-1) ? 0 : 1;
                dp[i][j] = Math.min(Math.min(dp[i-1][j] + 1, dp[i][j-1] + 1), dp[i-1][j-1] + cost);
            }
        return dp[m][n];
    }

    public int getWordCount() { return wordCount; }

    // ------------------------------------------------------------------ //
    //  Result DTO
    // ------------------------------------------------------------------ //

    public static class PhishResult {
        public final boolean isPhishing;
        public final int     threatLevel;
        public final String  reason;
        public PhishResult(boolean isPhishing, int threatLevel, String reason) {
            this.isPhishing  = isPhishing;
            this.threatLevel = threatLevel;
            this.reason      = reason;
        }
    }
}

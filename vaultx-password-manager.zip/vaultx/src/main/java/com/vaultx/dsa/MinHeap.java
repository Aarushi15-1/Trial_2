package com.vaultx.dsa;

import com.vaultx.model.LoginEvent;
import java.util.ArrayList;
import java.util.List;

/**
 * ============================================================
 * MIN-HEAP — Anomaly Priority Queue
 * ============================================================
 * Stores LoginEvents by anomaly risk score (lowest = most normal).
 * Allows the system to quickly surface the K most suspicious
 * login events for review.
 *
 *   insert(event)       → O(log n)
 *   extractMin()        → O(log n)  (lowest risk / oldest)
 *   peekMax()           → O(n)      (highest risk – for alerts)
 *   topK(k)             → O(n log n)
 *
 * Risk score is computed by LoginAnomalyDetector and embedded
 * in the LoginEvent before it is pushed onto this heap.
 * ============================================================
 */
public class MinHeap {

    private final List<LoginEvent> heap;

    public MinHeap() {
        this.heap = new ArrayList<>();
    }

    // ------------------------------------------------------------------ //
    //  Public API
    // ------------------------------------------------------------------ //

    public void insert(LoginEvent event) {
        heap.add(event);
        siftUp(heap.size() - 1);
    }

    /** Remove and return the event with the LOWEST risk score */
    public LoginEvent extractMin() {
        if (heap.isEmpty()) return null;
        LoginEvent min = heap.get(0);
        int last = heap.size() - 1;
        heap.set(0, heap.get(last));
        heap.remove(last);
        if (!heap.isEmpty()) siftDown(0);
        return min;
    }

    public LoginEvent peekMin() {
        return heap.isEmpty() ? null : heap.get(0);
    }

    /** Return the K events with the HIGHEST risk score (most suspicious) */
    public List<LoginEvent> topKMostSuspicious(int k) {
        List<LoginEvent> sorted = new ArrayList<>(heap);
        sorted.sort((a, b) -> Double.compare(b.getRiskScore(), a.getRiskScore()));
        return sorted.subList(0, Math.min(k, sorted.size()));
    }

    /** All events whose risk score exceeds a threshold */
    public List<LoginEvent> eventsAboveThreshold(double threshold) {
        List<LoginEvent> result = new ArrayList<>();
        for (LoginEvent e : heap) {
            if (e.getRiskScore() >= threshold) result.add(e);
        }
        return result;
    }

    public int  size()    { return heap.size(); }
    public boolean isEmpty() { return heap.isEmpty(); }

    // ------------------------------------------------------------------ //
    //  Heap maintenance
    // ------------------------------------------------------------------ //

    private void siftUp(int idx) {
        while (idx > 0) {
            int parent = (idx - 1) / 2;
            if (score(heap.get(idx)) < score(heap.get(parent))) {
                swap(idx, parent);
                idx = parent;
            } else break;
        }
    }

    private void siftDown(int idx) {
        int n = heap.size();
        while (true) {
            int left  = 2 * idx + 1;
            int right = 2 * idx + 2;
            int smallest = idx;

            if (left  < n && score(heap.get(left))  < score(heap.get(smallest))) smallest = left;
            if (right < n && score(heap.get(right)) < score(heap.get(smallest))) smallest = right;

            if (smallest != idx) { swap(idx, smallest); idx = smallest; }
            else break;
        }
    }

    private void swap(int i, int j) {
        LoginEvent tmp = heap.get(i);
        heap.set(i, heap.get(j));
        heap.set(j, tmp);
    }

    private double score(LoginEvent e) { return e.getRiskScore(); }
}

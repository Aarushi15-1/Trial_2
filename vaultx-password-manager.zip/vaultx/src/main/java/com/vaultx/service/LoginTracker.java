package com.vaultx.service;

import com.vaultx.dsa.AVLTree;
import com.vaultx.dsa.MinHeap;
import com.vaultx.model.LoginEvent;

import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * ============================================================
 * LOGIN TRACKER + ANOMALY DETECTOR
 * ============================================================
 * Per-user login history stored in AVL Tree (sorted by timestamp).
 * Anomaly scoring via risk heuristics → inserted into MinHeap.
 *
 * Anomaly signals:
 *   1. Unusual hour  (login between 00:00–05:00 local time → +0.3)
 *   2. New location  (first time from this country → +0.4)
 *   3. New IP        (never seen before → +0.2)
 *   4. Rapid logins  (>5 attempts in 10 min → +0.5)
 *   5. Failed login  (unsuccessful attempt → +0.3)
 *   6. Geographic impossibility (login from 2 countries within 1 hour → +0.8)
 *
 * Risk score 0.0–1.0; threshold 0.6 → send alert email.
 *
 * DSA: AVLTree (O(log n) insert/query), MinHeap (O(log n) priority)
 * ============================================================
 */
public class LoginTracker {

    // Per-user login history (AVL Tree)
    private static final Map<Integer, AVLTree> userTrees = new ConcurrentHashMap<>();
    // Global anomaly queue (MinHeap — surface highest risk events)
    private static final MinHeap anomalyHeap = new MinHeap();

    public static final double ALERT_THRESHOLD = 0.6;

    // ------------------------------------------------------------------ //
    //  Record Login
    // ------------------------------------------------------------------ //

    /**
     * Records a login event and computes its risk score.
     * @return the scored LoginEvent (caller should persist + check alertNeeded())
     */
    public static LoginEvent recordLogin(int userId, String ipAddress,
                                          String location, boolean successful) {
        LoginEvent event = new LoginEvent(userId, System.currentTimeMillis(),
                ipAddress, location, successful);

        // Get or create user's AVL tree
        userTrees.putIfAbsent(userId, new AVLTree());
        AVLTree tree = userTrees.get(userId);

        // Compute risk score before inserting
        double risk = computeRiskScore(userId, event, tree);
        event.setRiskScore(risk);

        // Insert into AVL tree
        tree.insert(event);

        // Insert into global anomaly heap if risky
        if (risk > 0.3) anomalyHeap.insert(event);

        // Auto-alert if above threshold
        if (risk >= ALERT_THRESHOLD) {
            event.setAlertSent(true);
            // EmailService.sendLoginAlert(userId, event);  // wired in EmailService
        }

        return event;
    }

    // ------------------------------------------------------------------ //
    //  Risk Scoring
    // ------------------------------------------------------------------ //

    private static double computeRiskScore(int userId, LoginEvent event, AVLTree tree) {
        double score = 0.0;
        StringBuilder reasons = new StringBuilder();

        // 1. Unusual hour (00:00 – 05:00)
        ZonedDateTime zdt = Instant.ofEpochMilli(event.getTimestamp())
                .atZone(ZoneId.of("UTC"));
        int hour = zdt.getHour();
        if (hour >= 0 && hour < 5) {
            score += 0.3;
            reasons.append("Unusual login hour (").append(hour).append(":00 UTC). ");
        }

        // 2. Failed login
        if (!event.isSuccessful()) {
            score += 0.3;
            reasons.append("Failed login attempt. ");
        }

        // Retrieve last 10 logins
        List<LoginEvent> recent = tree.inorderList();
        int historySize = recent.size();

        if (historySize == 0) {
            // First ever login — assign low base risk
            score += 0.1;
            reasons.append("First login from this device. ");
        } else {
            // 3. New IP address
            boolean seenIp = recent.stream().anyMatch(e -> e.getIpAddress().equals(event.getIpAddress()));
            if (!seenIp) {
                score += 0.2;
                reasons.append("New IP address: ").append(event.getIpAddress()).append(". ");
            }

            // 4. New location / country
            String country = extractCountry(event.getLocation());
            boolean seenCountry = recent.stream()
                    .anyMatch(e -> extractCountry(e.getLocation()).equalsIgnoreCase(country));
            if (!seenCountry && !country.isEmpty()) {
                score += 0.4;
                reasons.append("Login from new country: ").append(country).append(". ");
            }

            // 5. Rapid login attempts (> 5 in last 10 minutes)
            long tenMinAgo = event.getTimestamp() - 10 * 60 * 1000L;
            List<LoginEvent> lastTenMin = tree.rangeQuery(tenMinAgo, event.getTimestamp());
            if (lastTenMin.size() >= 5) {
                score += 0.5;
                reasons.append("Brute-force pattern: ").append(lastTenMin.size()).append(" logins in 10 min. ");
            }

            // 6. Geographic impossibility
            if (!recent.isEmpty()) {
                LoginEvent lastLogin = recent.get(recent.size() - 1);
                long timeDiffHours = (event.getTimestamp() - lastLogin.getTimestamp()) / 3_600_000L;
                String lastCountry = extractCountry(lastLogin.getLocation());
                if (!lastCountry.equalsIgnoreCase(country) && timeDiffHours < 2
                        && !country.isEmpty() && !lastCountry.isEmpty()) {
                    score += 0.8;
                    reasons.append("Geographic impossibility: login from ")
                            .append(lastCountry).append(" → ").append(country)
                            .append(" within ").append(timeDiffHours).append("h. ");
                }
            }
        }

        event.setRiskReason(reasons.toString().trim());
        return Math.min(1.0, score);
    }

    // ------------------------------------------------------------------ //
    //  Query API
    // ------------------------------------------------------------------ //

    /** Get all login events for a user (chronologically sorted via AVL inorder) */
    public static List<LoginEvent> getLoginHistory(int userId) {
        AVLTree tree = userTrees.get(userId);
        return tree == null ? new ArrayList<>() : tree.inorderList();
    }

    /** Get logins in a time range */
    public static List<LoginEvent> getLoginsInRange(int userId, long startMs, long endMs) {
        AVLTree tree = userTrees.get(userId);
        return tree == null ? new ArrayList<>() : tree.rangeQuery(startMs, endMs);
    }

    /** Get top-K most suspicious logins system-wide */
    public static List<LoginEvent> getMostSuspiciousLogins(int k) {
        return anomalyHeap.topKMostSuspicious(k);
    }

    /** Check if a specific login should trigger an alert */
    public static boolean alertNeeded(LoginEvent event) {
        return event.getRiskScore() >= ALERT_THRESHOLD;
    }

    // ------------------------------------------------------------------ //
    //  Helper
    // ------------------------------------------------------------------ //

    private static String extractCountry(String location) {
        if (location == null || location.isBlank()) return "";
        String[] parts = location.split(",");
        return parts.length > 1 ? parts[parts.length - 1].trim() : location.trim();
    }
}

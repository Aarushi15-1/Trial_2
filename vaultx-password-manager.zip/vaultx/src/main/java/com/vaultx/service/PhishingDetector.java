package com.vaultx.service;

import com.vaultx.crypto.CryptoUtil;
import com.vaultx.dsa.BloomFilter;
import com.vaultx.dsa.Trie;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.security.KeyPair;
import java.security.PublicKey;
import java.util.HashMap;
import java.util.Map;

/**
 * ============================================================
 * PHISHING DETECTOR
 * ============================================================
 * Multi-layer URL safety analysis:
 *
 *   Layer 1 — Bloom Filter (O(k))
 *             Fast negative: if not in filter → almost certainly safe
 *
 *   Layer 2 — Trie exact + prefix match (O(L))
 *             Confirmed phishing domains + typosquat detection
 *             Levenshtein distance on similar domains
 *
 *   Layer 3 — Heuristic analysis
 *             IP-based URLs, excessive subdomains, brand spoofing,
 *             suspicious keywords, URL length anomalies
 *
 *   Layer 4 — Digital Signature Verification (ECDSA)
 *             Sites can register a trusted signature. VaultX verifies
 *             the domain certificate fingerprint is signed by VaultX CA.
 *
 * DSA used: BloomFilter, Trie, HashTable (trusted site registry)
 * ============================================================
 */
public class PhishingDetector {

    private static final Trie        phishingTrie   = new Trie();
    private static final BloomFilter phishingFilter = new BloomFilter(500_000, 7);
    private static final Map<String, String> trustedSiteSignatures = new HashMap<>();

    // VaultX internal CA key pair (generated once at startup)
    private static KeyPair caKeyPair;
    private static boolean initialised = false;

    public static synchronized void init() {
        if (initialised) return;
        caKeyPair = CryptoUtil.generateECKeyPair();
        seedPhishingData();
        initialised = true;
    }

    // ------------------------------------------------------------------ //
    //  Main Analysis
    // ------------------------------------------------------------------ //

    public static PhishingResult analyzeUrl(String url) {
        init();

        if (url == null || url.isBlank()) {
            return new PhishingResult(false, 0, "URL_EMPTY", "No URL provided");
        }

        url = normalizeUrl(url);
        String domain = Trie.extractDomain(url);

        // Layer 1: Bloom filter fast-path
        if (!phishingFilter.mightContain(domain)) {
            // Not in bloom filter → run heuristics only (might still be suspicious)
            Trie.PhishResult heuristic = phishingTrie.analyzeUrl(url);
            if (heuristic.isPhishing) {
                return new PhishingResult(true, heuristic.threatLevel, "HEURISTIC", heuristic.reason);
            }
            return new PhishingResult(false, 0, "SAFE", "URL passed all checks");
        }

        // Layer 2: Trie exact + prefix + Levenshtein
        Trie.PhishResult trieResult = phishingTrie.analyzeUrl(url);
        if (trieResult.isPhishing) {
            return new PhishingResult(true, trieResult.threatLevel, "BLOCKLIST", trieResult.reason);
        }

        // Layer 3: Digital signature verification
        if (trustedSiteSignatures.containsKey(domain)) {
            boolean valid = verifyDomainSignature(domain, trustedSiteSignatures.get(domain));
            if (!valid) {
                return new PhishingResult(true, 3, "SIGNATURE_MISMATCH",
                        "Domain signature does not match trusted registry — possible DNS hijacking!");
            }
            return new PhishingResult(false, 0, "VERIFIED", "Domain signature verified ✓");
        }

        // Bloom filter had a hit but Trie/signature checks passed → false positive
        return new PhishingResult(false, 0, "SAFE", "URL appears safe (bloom false-positive cleared)");
    }

    // ------------------------------------------------------------------ //
    //  Digital Signature Verification
    // ------------------------------------------------------------------ //

    /**
     * Registers a trusted site with a CA-signed domain certificate fingerprint.
     * Called by site administrators; signed with VaultX CA private key.
     */
    public static String registerTrustedSite(String domain) {
        init();
        byte[] domainBytes = domain.getBytes(StandardCharsets.UTF_8);
        String signature   = CryptoUtil.sign(domainBytes, caKeyPair.getPrivate());
        trustedSiteSignatures.put(domain, signature);
        return signature;
    }

    /** Verifies the domain's signature against the VaultX CA public key */
    public static boolean verifyDomainSignature(String domain, String signature) {
        init();
        byte[] domainBytes = domain.getBytes(StandardCharsets.UTF_8);
        PublicKey pubKey   = caKeyPair.getPublic();
        return CryptoUtil.verify(domainBytes, signature, pubKey);
    }

    // ------------------------------------------------------------------ //
    //  Seeding
    // ------------------------------------------------------------------ //

    private static void seedPhishingData() {
        String[] phishingDomains = {
            "paypa1.com", "secure-paypal.com", "paypal-login.net",
            "appleid-verify.com", "apple-support-login.com", "apple-account-secure.net",
            "google-security-alert.com", "gmail-login-secure.net",
            "microsoftsupport-login.com", "microsoft365-update.net",
            "amazon-delivery-update.com", "amazon-prime-verify.net",
            "facebook-login-help.com", "fb-security-check.net",
            "netflix-billing-update.com", "netflix-account-verify.com",
            "bankofamerica-secure.net", "chase-online-verify.com",
            "wellsfargo-update-account.com", "citibank-alert-login.com",
            "irs-tax-refund-2024.com", "covid-relief-fund.net",
            "bit1y.com", "g00gle.com", "amaz0n.com", "faceb00k.com"
        };

        for (String domain : phishingDomains) {
            phishingTrie.insert(domain, 2);
            phishingFilter.add(domain);
        }

        // High-threat malware sites (level 3)
        String[] malwareDomains = {
            "free-download-virus.com", "crack-software-free.net",
            "ransomware-payload.ru", "exploit-kit-landing.com"
        };
        for (String domain : malwareDomains) {
            phishingTrie.insert(domain, 3);
            phishingFilter.add(domain);
        }
    }

    // ------------------------------------------------------------------ //
    //  Helpers
    // ------------------------------------------------------------------ //

    private static String normalizeUrl(String url) {
        if (!url.startsWith("http")) url = "https://" + url;
        return url.trim().toLowerCase();
    }

    // ------------------------------------------------------------------ //
    //  Result DTO
    // ------------------------------------------------------------------ //

    public static class PhishingResult {
        public final boolean isPhishing;
        public final int     threatLevel;   // 0=safe, 1=suspicious, 2=phishing, 3=malware
        public final String  riskType;      // SAFE | HEURISTIC | BLOCKLIST | SIGNATURE_MISMATCH | VERIFIED
        public final String  message;

        public PhishingResult(boolean isPhishing, int threatLevel, String riskType, String message) {
            this.isPhishing  = isPhishing;
            this.threatLevel = threatLevel;
            this.riskType    = riskType;
            this.message     = message;
        }

        public String getThreatLabel() {
            return switch (threatLevel) {
                case 0 -> "Safe";
                case 1 -> "Suspicious";
                case 2 -> "Phishing";
                case 3 -> "Malware";
                default -> "Unknown";
            };
        }
    }
}

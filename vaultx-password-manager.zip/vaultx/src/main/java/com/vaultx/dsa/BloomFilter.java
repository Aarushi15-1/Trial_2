package com.vaultx.dsa;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.BitSet;

/**
 * ============================================================
 * BLOOM FILTER — Probabilistic Data Structure
 * ============================================================
 * Space-efficient set membership test with no false negatives.
 * Used for:
 *   1. Breached password detection (HIBP-style)
 *   2. Phishing URL detection
 *   3. Banned domain list
 *
 * Time  : O(k) insert / O(k) lookup  where k = number of hash functions
 * Space : O(m) bits  (much smaller than a HashSet)
 *
 * False-positive probability:  p ≈ (1 - e^(-kn/m))^k
 *   n = expected elements, m = bit-array size, k = hash functions
 * ============================================================
 */
public class BloomFilter {

    private final BitSet  bitSet;
    private final int     bitSetSize;
    private final int     numHashFunctions;
    private       int     insertedElements;

    // Optimal defaults for ~1% FP rate with 100 000 items → 958 505 bits, 7 hashes
    private static final int DEFAULT_BITS   = 958_505;
    private static final int DEFAULT_HASHES = 7;

    public BloomFilter() {
        this(DEFAULT_BITS, DEFAULT_HASHES);
    }

    /**
     * @param bitSetSize       m – total number of bits
     * @param numHashFunctions k – number of independent hash functions
     */
    public BloomFilter(int bitSetSize, int numHashFunctions) {
        this.bitSetSize       = bitSetSize;
        this.numHashFunctions = numHashFunctions;
        this.bitSet           = new BitSet(bitSetSize);
        this.insertedElements = 0;
    }

    // ------------------------------------------------------------------ //
    //  Core Operations
    // ------------------------------------------------------------------ //

    /**
     * Insert an item into the filter.
     * Sets k bit positions derived from the item.
     */
    public void add(String item) {
        for (int seed = 0; seed < numHashFunctions; seed++) {
            int index = hash(item, seed);
            bitSet.set(index);
        }
        insertedElements++;
    }

    /**
     * Test membership.
     * @return false  → item is DEFINITELY NOT in the set
     *         true   → item is PROBABLY in the set (may be a false positive)
     */
    public boolean mightContain(String item) {
        for (int seed = 0; seed < numHashFunctions; seed++) {
            int index = hash(item, seed);
            if (!bitSet.get(index)) return false;   // definitive negative
        }
        return true;   // probable positive
    }

    // ------------------------------------------------------------------ //
    //  Double-Hashing Scheme  (Kirsch–Mitzenmacher trick)
    //  h_i(x) = h1(x) + i * h2(x)  mod m
    //  Generates k independent-looking positions using only 2 base hashes.
    // ------------------------------------------------------------------ //

    private int hash(String item, int seed) {
        byte[] h1Bytes = sha256(item);
        byte[] h2Bytes = md5(item);

        long h1 = toLong(h1Bytes, 0);
        long h2 = toLong(h2Bytes, 0);

        long combined = Math.abs(h1 + (long) seed * h2);
        return (int)(combined % bitSetSize);
    }

    private byte[] sha256(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            return md.digest(input.getBytes(StandardCharsets.UTF_8));
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 not available", e);
        }
    }

    private byte[] md5(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            return md.digest(input.getBytes(StandardCharsets.UTF_8));
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("MD5 not available", e);
        }
    }

    /** Read 8 bytes from a byte array as a big-endian long */
    private long toLong(byte[] bytes, int offset) {
        long val = 0L;
        for (int i = offset; i < Math.min(offset + 8, bytes.length); i++) {
            val = (val << 8) | (bytes[i] & 0xFF);
        }
        return val;
    }

    // ------------------------------------------------------------------ //
    //  Diagnostics
    // ------------------------------------------------------------------ //

    /** Estimated false-positive probability given current fill. */
    public double falsePositiveProbability() {
        double k = numHashFunctions;
        double n = insertedElements;
        double m = bitSetSize;
        return Math.pow(1 - Math.exp(-k * n / m), k);
    }

    public int getInsertedElements() { return insertedElements; }
    public int getBitSetSize()       { return bitSetSize; }
    public int getNumHashFunctions() { return numHashFunctions; }

    @Override
    public String toString() {
        return String.format("BloomFilter[bits=%d, hashes=%d, items=%d, FP≈%.4f%%]",
                bitSetSize, numHashFunctions, insertedElements,
                falsePositiveProbability() * 100);
    }
}

package com.vaultx.util;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;

/**
 * Adds OWASP-recommended security headers to every response.
 */
public class SecurityFilter implements Filter {
    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
            throws IOException, ServletException {
        HttpServletResponse response = (HttpServletResponse) res;

        // Prevent clickjacking
        response.setHeader("X-Frame-Options", "DENY");
        // Prevent MIME sniffing
        response.setHeader("X-Content-Type-Options", "nosniff");
        // XSS protection (legacy browsers)
        response.setHeader("X-XSS-Protection", "1; mode=block");
        // Referrer policy
        response.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
        // Content Security Policy
        response.setHeader("Content-Security-Policy",
                "default-src 'self'; script-src 'self' 'unsafe-inline'; " +
                "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; " +
                "font-src https://fonts.gstatic.com;");

        chain.doFilter(req, res);
    }
}
